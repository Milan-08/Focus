'use strict';
// Zelftest: nep-Discord + nep-FiveM + de echte website. Start met: node test/run.js
const http = require('node:http');
const { spawn } = require('node:child_process');
const assert = require('node:assert/strict');
const path = require('node:path');

const listen = (handler) => new Promise((r) => { const s = http.createServer(handler); s.listen(0, '127.0.0.1', () => r(s)); });
const body = (req) => new Promise((r) => { let b = ''; req.on('data', (c) => b += c); req.on('end', () => r(b)); });

(async () => {
  const seen = { fivem: [] };
  const discord = await listen(async (req, res) => {
    if (req.url === '/api/oauth2/token') { await body(req); res.setHeader('Content-Type', 'application/json'); return res.end(JSON.stringify({ access_token: 'tok' })); }
    if (req.url === '/api/users/@me') { res.setHeader('Content-Type', 'application/json'); return res.end(JSON.stringify({ id: '1234567890', username: 'agent' })); }
    res.statusCode = 404; res.end();
  });
  let online = true;
  const fivem = await listen(async (req, res) => {
    const data = JSON.parse(await body(req));
    seen.fivem.push({ secret: req.headers['x-mdt-secret'], data });
    res.setHeader('Content-Type', 'application/json');
    if (req.headers['x-mdt-secret'] !== 'geheimgeheimgeheim') { res.statusCode = 401; return res.end('{"error":"bad_secret"}'); }
    if (!online) return res.end(JSON.stringify({ ok: false, error: 'offline' }));
    if (data.action === 'nope') return res.end(JSON.stringify({ ok: false, error: 'denied' }));
    res.end(JSON.stringify({ ok: true, result: { echo: data.action, discord: data.discord } }));
  });
  const port = 3999;
  const child = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], {
    env: { ...process.env, PORT: String(port), PUBLIC_URL: `http://127.0.0.1:${port}`, DISCORD_CLIENT_ID: 'id', DISCORD_CLIENT_SECRET: 'secret',
      DISCORD_BASE: `http://127.0.0.1:${discord.address().port}`, FIVEM_URL: `http://127.0.0.1:${fivem.address().port}/p_mdt/web/api`,
      FIVEM_SECRET: 'geheimgeheimgeheim', SESSION_SECRET: 'x'.repeat(40) }, stdio: ['ignore', 'pipe', 'inherit'] });
  await new Promise((r) => child.stdout.on('data', (d) => String(d).includes('draait') && r()));
  const base = `http://127.0.0.1:${port}`;
  const j = (cookie, extra = {}) => ({ headers: { 'Content-Type': 'application/json', 'X-MDT': '1', ...(cookie ? { Cookie: cookie } : {}) }, ...extra });
  let pass = 0; const ok = (name) => { pass++; console.log('ok  ', name); };
  try {
    // 1. niet ingelogd
    let r = await fetch(`${base}/api`, j(null, { method: 'POST', body: '{"action":"dashboard"}' }));
    assert.equal(r.status, 401); ok('API zonder login geweigerd');
    r = await fetch(`${base}/api/me`); assert.deepEqual(await r.json(), { loggedIn: false }); ok('/api/me zonder login');

    // 2. inloggen
    r = await fetch(`${base}/auth/login`, { redirect: 'manual' });
    assert.equal(r.status, 302);
    const loc = new URL(r.headers.get('location'));
    assert.equal(loc.searchParams.get('client_id'), 'id'); assert.equal(loc.searchParams.get('scope'), 'identify');
    const state = loc.searchParams.get('state');
    const stateCookie = r.headers.getSetCookie().map((c) => c.split(';')[0]).find((c) => c.startsWith('mdt_state='));
    ok('login stuurt door naar Discord met state');

    r = await fetch(`${base}/auth/callback?code=abc&state=fout`, { redirect: 'manual', headers: { Cookie: stateCookie } });
    assert.equal(r.status, 400); ok('verkeerde state geweigerd');

    r = await fetch(`${base}/auth/callback?code=abc&state=${state}`, { redirect: 'manual', headers: { Cookie: stateCookie } });
    assert.equal(r.status, 302);
    const sess = r.headers.getSetCookie().map((c) => c.split(';')[0]).find((c) => c.startsWith('mdt_session=') && c.length > 14);
    assert.ok(sess); assert.ok(r.headers.getSetCookie().some((c) => /HttpOnly/i.test(c) && c.startsWith('mdt_session')));
    ok('callback maakt sessiecookie (HttpOnly)');

    r = await fetch(`${base}/api/me`, { headers: { Cookie: sess } });
    assert.equal((await r.json()).loggedIn, true); ok('/api/me met sessie');

    // 3. API doorsturen
    r = await fetch(`${base}/api`, j(sess, { method: 'POST', body: '{"action":"dashboard","payload":{"a":1}}' }));
    assert.equal(r.status, 200);
    assert.deepEqual(await r.json(), { echo: 'dashboard', discord: '1234567890' });
    const last = seen.fivem.at(-1);
    assert.equal(last.secret, 'geheimgeheimgeheim'); assert.equal(last.data.discord, '1234567890'); assert.deepEqual(last.data.payload, { a: 1 });
    ok('API wordt met geheime sleutel en Discord-ID doorgestuurd');

    // discord-id uit de client wordt genegeerd
    await fetch(`${base}/api`, j(sess, { method: 'POST', body: '{"action":"x","discord":"999"}' }));
    assert.equal(seen.fivem.at(-1).data.discord, '1234567890'); ok('Discord-ID uit het verzoek wordt genegeerd');

    r = await fetch(`${base}/api`, j(sess, { method: 'POST', body: '{"action":"nope"}' })); assert.equal(r.status, 403); ok('denied -> 403');
    online = false;
    r = await fetch(`${base}/api`, j(sess, { method: 'POST', body: '{"action":"dashboard"}' }));
    assert.equal(r.status, 409); assert.deepEqual(await r.json(), { error: 'offline' }); ok('personage offline -> 409 offline');
    online = true;

    // 4. beveiliging
    r = await fetch(`${base}/api`, { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: sess }, body: '{"action":"dashboard"}' });
    assert.equal(r.status, 400); ok('zonder X-MDT-header geweigerd (CSRF)');
    r = await fetch(`${base}/api`, j(sess, { method: 'POST', body: '{"action":"../etc"}' })); assert.equal(r.status, 400); ok('ongeldige actienaam geweigerd');
    const tampered = sess.replace(/.$/, (c) => (c === 'A' ? 'B' : 'A'));
    r = await fetch(`${base}/api`, j(tampered, { method: 'POST', body: '{"action":"dashboard"}' })); assert.equal(r.status, 401); ok('aangepaste cookie geweigerd');
    r = await fetch(`${base}/api`, j(sess, { method: 'POST', body: 'x'.repeat(200_000) })); assert.ok([400, 413].includes(r.status) || r.status === 0); ok('te grote body geweigerd');
  } catch (e) {
    if (String(e).includes('fetch failed') && !0) { /* te grote body sluit de verbinding */ pass++; console.log('ok   te grote body geweigerd (verbinding gesloten)'); } else throw e;
  }
  // 5. statische bestanden
  let r = await fetch(`${base}/`); assert.equal(r.status, 200); assert.match(await r.text(), /Politie MDT/); console.log('ok   index.html'); pass++;
  r = await fetch(`${base}/app.js`); assert.equal(r.status, 200); console.log('ok   app.js'); pass++;
  r = await fetch(`${base}/..%2fserver.js`); assert.notEqual(r.status, 200); console.log('ok   path traversal geweigerd'); pass++;
  r = await fetch(`${base}/%2e%2e/.env.example`); assert.notEqual(r.status, 200); console.log('ok   path traversal 2 geweigerd'); pass++;
  assert.ok(r.headers.get('x-content-type-options') === 'nosniff'); console.log('ok   beveiligingsheaders'); pass++;

  console.log(`\n${pass} controles geslaagd`);
  child.kill(); discord.close(); fivem.close();
})().catch((e) => { console.error('MISLUKT:', e); process.exit(1); });
