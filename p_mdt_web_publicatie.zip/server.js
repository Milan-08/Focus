'use strict';
// p_mdt_web: website voor de politie-MDT. Geen externe pakketten nodig (enkel Node 18+).
// Doet drie dingen: inloggen met Discord, de pagina's tonen en verzoeken doorsturen naar de FiveM-server.

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

// --- instellingen (.env) ----------------------------------------------------
function loadEnv(file) {
  const out = {};
  let text = '';
  try { text = fs.readFileSync(file, 'utf8'); } catch { return out; }
  for (const line of text.split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (!m || line.trim().startsWith('#')) continue;
    out[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
  return out;
}
const env = { ...loadEnv(path.join(__dirname, '.env')), ...process.env };
const cfg = {
  port: Number(env.PORT || 3000),
  host: env.HOST || '0.0.0.0',
  publicUrl: (env.PUBLIC_URL || 'http://localhost:3000').replace(/\/+$/, ''),
  clientId: env.DISCORD_CLIENT_ID || '',
  clientSecret: env.DISCORD_CLIENT_SECRET || '',
  discordGuildId: env.DISCORD_GUILD_ID || '',
  allowedRoleIds: (env.DISCORD_ALLOWED_ROLE_IDS || '').split(',').map((id) => id.trim()).filter(Boolean),
  adminRoleIds: (env.DISCORD_ADMIN_ROLE_IDS || '').split(',').map((id) => id.trim()).filter(Boolean),
  rankRoleIds: (env.DISCORD_RANK_ROLE_IDS || '').split(',').map((id) => id.trim()).filter(Boolean),
  rankNames: {
    '1509571357833298060': 'Korpsleiding',
    '1509571356424147077': 'Politie',
    '1509571358504390849': 'Commissaris-generaal',
    '1509571359703826462': 'Eerste Hoofdcommissaris',
    '1509571360622514176': 'Directeur-generaal',
    '1509571361700577451': 'Coördinator-directeur',
    '1509571362556088320': 'Directeur',
    '1509571363382497390': 'Hoofdcommissaris',
    '1509571364158439586': 'Eerste commissaris',
    '1509571364997038123': 'Commissaris',
    '1509571366112722948': 'Aspirant-commissaris',
    '1509571366909903029': 'Eerste hoofdinspecteur',
    '1509571368230981712': 'Hoofdinspecteur',
    '1509571369417834536': 'Aspirant-hoofdinspecteur',
    '1509571370269544588': 'Eerste inspecteur',
    '1509571371150344352': 'Inspecteur',
    '1509571372429480089': 'Aspirant-inspecteur',
    '1509571373427593458': 'Aspirant Agent',
  },
  discordBase: (env.DISCORD_BASE || 'https://discord.com').replace(/\/+$/, ''),
  fivemUrl: (env.FIVEM_URL || '').replace(/\/+$/, ''),
  fivemSecret: env.FIVEM_SECRET || '',
  sessionSecret: env.SESSION_SECRET || '',
  sessionHours: Math.max(1, Math.min(72, Number(env.SESSION_HOURS || 12))),
};
if (!Number.isFinite(cfg.sessionHours)) cfg.sessionHours = 12;
const publicHostname = (() => { try { return new URL(cfg.publicUrl).hostname.toLowerCase(); } catch { return ''; } })();
const loopbackHost = publicHostname === 'localhost' || publicHostname === '127.0.0.1' || cfg.host === '127.0.0.1' || cfg.host === 'localhost';
if (publicHostname === 'localhost' || publicHostname === '127.0.0.1') console.warn('[p_mdt_web] PUBLIC_URL wijst naar deze computer. Discord-login en links werken dan alleen lokaal; vul voor publicatie je echte https-adres in.');
if (cfg.host === '127.0.0.1' || cfg.host === 'localhost') console.warn('[p_mdt_web] HOST bindt alleen aan deze computer. Gebruik op een server HOST=0.0.0.0.');
const problems = [];
if (!cfg.clientId || !cfg.clientSecret) problems.push('DISCORD_CLIENT_ID en DISCORD_CLIENT_SECRET ontbreken');
if (!cfg.fivemUrl) problems.push('FIVEM_URL ontbreekt (bv. http://127.0.0.1:30120/p_mdt/web/api)');
if (cfg.fivemSecret.length < 16) problems.push('FIVEM_SECRET moet minstens 16 tekens zijn (zelfde als Config.Web.Secret in p_mdt)');
if (cfg.sessionSecret.length < 32) problems.push('SESSION_SECRET moet minstens 32 tekens zijn');
if (problems.length) {
  console.error('Instellingen onvolledig:\n - ' + problems.join('\n - '));
  process.exit(1);
}
const secureCookie = cfg.publicUrl.startsWith('https://');
const roleGateReady = /^\d{17,20}$/.test(cfg.discordGuildId)
  && cfg.allowedRoleIds.length > 0
  && cfg.allowedRoleIds.every((id) => /^\d{17,20}$/.test(id));
if (!roleGateReady) console.error('[p_mdt_web] Discord-roltoegang staat gesloten: vul DISCORD_GUILD_ID en DISCORD_ALLOWED_ROLE_IDS in.');

// --- sessies: ondertekende cookie ----------------------------------------------
const b64 = (buf) => Buffer.from(buf).toString('base64url');
const sign = (data) => crypto.createHmac('sha256', cfg.sessionSecret).update(data).digest('base64url');

function makeToken(payload) {
  const body = b64(JSON.stringify(payload));
  return `${body}.${sign(body)}`;
}
function readToken(token) {
  if (typeof token !== 'string') return null;
  const [body, mac] = token.split('.');
  if (!body || !mac) return null;
  const expected = sign(body);
  const a = Buffer.from(mac), b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const p = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (!p || typeof p.exp !== 'number' || p.exp < Date.now()) return null;
    return p;
  } catch { return null; }
}
function cookies(req) {
  const out = {};
  for (const part of (req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) {
      try { out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim()); }
      catch { /* Een ongeldige cookie negeren, zodat de rest van de site blijft werken. */ }
    }
  }
  return out;
}
function setCookie(res, name, value, maxAgeSec) {
  const parts = [`${name}=${encodeURIComponent(value)}`, 'Path=/', 'HttpOnly', 'SameSite=Lax', `Max-Age=${maxAgeSec}`];
  if (secureCookie) parts.push('Secure');
  const prev = res.getHeader('Set-Cookie') || [];
  res.setHeader('Set-Cookie', [].concat(prev, parts.join('; ')));
}
const sessions = new Map(); // OAuth access tokens blijven alleen server-side
setInterval(() => {
  const now = Date.now();
  for (const [sid, s] of sessions) if (s.exp < now) sessions.delete(sid);
}, 60_000).unref();
function session(req) {
  const token = readToken(cookies(req).mdt_session);
  if (!token || !token.sid) return null;
  const data = sessions.get(token.sid);
  if (!data || data.exp !== token.exp || data.exp < Date.now()) {
    sessions.delete(token.sid);
    return null;
  }
  data.sid = token.sid;
  return data;
}

async function checkDiscordRoles(s) {
  if (!roleGateReady) return { allowed: false, setup: true };
  if (s.rolesCheckedAt && Date.now() - s.rolesCheckedAt < 20_000) return { allowed: s.rolesAllowed, admin: s.webAdmin };
  try {
    const endpoint = cfg.discordBase + '/api/users/@me/guilds/' + cfg.discordGuildId + '/member';
    const r = await fetch(endpoint, { headers: { Authorization: 'Bearer ' + s.accessToken }, signal: AbortSignal.timeout(8000) });
    if (r.status === 401) return { allowed: false, invalidToken: true };
    if (r.status === 403) {
      console.warn('[p_mdt_web] Discord rolcontrole geweigerd (403), OAuth scopes: ' + (s.oauthScope || 'niet teruggegeven'));
      return { allowed: false, unavailable: true, reason: 'discord_forbidden' };
    }
    if (r.status === 404) {
      s.rolesAllowed = false; s.webAdmin = false; s.roles = []; s.guildNickname = ''; s.rank = ''; s.rolesCheckedAt = Date.now();
      return { allowed: false };
    }
    if (!r.ok) {
      console.warn('[p_mdt_web] Discord rolcontrole gaf HTTP ' + r.status + ' terug.');
      return { allowed: false, unavailable: true, reason: 'discord_unavailable' };
    }
    const member = await r.json();
    const roles = Array.isArray(member.roles) ? member.roles : [];
    s.roles = roles;
    s.guildNickname = String(member.nick || '').slice(0, 80);
    s.rank = cfg.rankRoleIds.find((id) => roles.includes(id)) || '';
    s.webAdmin = cfg.adminRoleIds.some((id) => roles.includes(id));
    s.rolesAllowed = cfg.allowedRoleIds.some((id) => roles.includes(id));
    s.rolesCheckedAt = Date.now();
    return { allowed: s.rolesAllowed, admin: s.webAdmin };
  } catch (e) {
    console.warn('[p_mdt_web] Discord rolcontrole netwerkfout: ' + (e && e.name ? e.name : 'onbekend'));
    return { allowed: false, unavailable: true, reason: 'discord_unavailable' };
  }
}

// --- hulpfuncties --------------------------------------------------------------
const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'same-origin',
  'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' https: data:; script-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
};
function send(res, code, body, headers = {}) {
  const isObj = body !== null && typeof body === 'object' && !Buffer.isBuffer(body);
  res.writeHead(code, { ...SECURITY_HEADERS, 'Content-Type': isObj ? 'application/json; charset=utf-8' : 'text/plain; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(isObj ? JSON.stringify(body) : body);
}
function readBody(req, limit = 100_000) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > limit) { reject(new Error('too_large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}
const rate = new Map(); // discord id -> { n, reset }
function limited(id) {
  const now = Date.now();
  let r = rate.get(id);
  if (!r || r.reset < now) { r = { n: 0, reset: now + 60_000 }; rate.set(id, r); }
  if (++r.n > 240) return true;
  if (rate.size > 10_000) {
    for (const [key, value] of rate) {
      if (value.reset < now) rate.delete(key);
      if (rate.size <= 9_000) break;
    }
  }
  return false;
}
setInterval(() => { const now = Date.now(); for (const [k, v] of rate) if (v.reset < now) rate.delete(k); }, 60_000).unref();

// --- Discord inloggen ------------------------------------------------------------
const redirectUri = `${cfg.publicUrl}/auth/callback`;

function login(req, res) {
  if (!roleGateReady) return send(res, 503, 'MDT-roltoegang is nog niet ingesteld. De beheerder moet de Discord-server-ID en toegestane politie-rol-ID’s invullen.');
  const state = crypto.randomBytes(16).toString('hex');
  setCookie(res, 'mdt_state', state, 600);
  const q = new URLSearchParams({ client_id: cfg.clientId, redirect_uri: redirectUri, response_type: 'code', scope: 'identify guilds.members.read', state });
  if (new URL(req.url, cfg.publicUrl).searchParams.get('reauthorize') === '1') q.set('prompt', 'consent');
  send(res, 302, '', { Location: `${cfg.discordBase}/oauth2/authorize?${q}` });
}

async function callback(req, res, url) {
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state');
  const saved = cookies(req).mdt_state;
  setCookie(res, 'mdt_state', '', 0);
  if (!code || !state || !saved || state !== saved) return send(res, 400, 'Inloggen mislukt (ongeldige status). Probeer opnieuw.');
  try {
    const tokenRes = await fetch(`${cfg.discordBase}/api/oauth2/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ client_id: cfg.clientId, client_secret: cfg.clientSecret, grant_type: 'authorization_code', code, redirect_uri: redirectUri }),
      signal: AbortSignal.timeout(8000),
    });
    if (!tokenRes.ok) return send(res, 400, 'Inloggen mislukt (Discord weigerde de code).');
    const token = await tokenRes.json();
    if (!token.access_token) return send(res, 400, 'Inloggen mislukt (Discord gaf geen toegangstoken terug).');
    const meRes = await fetch(`${cfg.discordBase}/api/users/@me`, { headers: { Authorization: `Bearer ${token.access_token}` }, signal: AbortSignal.timeout(8000) });
    if (!meRes.ok) return send(res, 400, 'Inloggen mislukt (profiel niet op te halen).');
    const me = await meRes.json();
    if (!me.id || !/^\d+$/.test(me.id)) return send(res, 400, 'Inloggen mislukt.');
    const exp = Date.now() + cfg.sessionHours * 3600_000;
    if (!roleGateReady) return send(res, 503, 'MDT-roltoegang is nog niet ingesteld. De beheerder moet de Discord-server-ID en toegestane politie-rol-ID’s invullen.');
    const userSession = {
      d: me.id, u: String(me.global_name || me.username || '').slice(0, 40),
      handle: String(me.username || '').slice(0, 40),
      avatar: me.avatar ? `https://cdn.discordapp.com/avatars/${me.id}/${me.avatar}.png?size=96` : `https://cdn.discordapp.com/embed/avatars/${Number(BigInt(me.id) >> 22n) % 6}.png`,
      accessToken: token.access_token, oauthScope: String(token.scope || ''), exp, rolesCheckedAt: 0, rolesAllowed: false,
    };
    const roleCheck = await checkDiscordRoles(userSession);
    if (roleCheck.unavailable) { const msg = roleCheck.reason === 'discord_forbidden' ? 'Discord weigert toegang tot je serverrollen. Controleer OAuth2-scope guilds.members.read en geef FOCUS opnieuw toestemming.' : 'Discord reageert tijdelijk niet op de rollencontrole. Probeer het straks opnieuw.'; return send(res, 503, msg + ' <a href="/auth/login?reauthorize=1">Opnieuw toestemming geven</a>.', { 'Content-Type': 'text/html; charset=utf-8' }); }
    if (!roleCheck.allowed) return send(res, 403, 'Geen toegang tot FOCUS MDT. Je moet lid zijn van de ingestelde Discord-server en minstens één toegestane politierol hebben.');
    const sid = crypto.randomBytes(32).toString('base64url');
    sessions.set(sid, userSession);
    setCookie(res, 'mdt_session', makeToken({ sid, exp }), cfg.sessionHours * 3600);
    send(res, 302, '', { Location: '/' });
  } catch (e) {
    send(res, 502, 'Discord is niet bereikbaar. Probeer het straks opnieuw.');
  }
}

// --- API naar de FiveM-server ---------------------------------------------------------
async function api(req, res) {
  const s = session(req);
  if (!s) return send(res, 401, { error: 'login' });
  const roleCheck = await checkDiscordRoles(s);
  if (roleCheck.unavailable) return send(res, 503, { error: 'role_check_unavailable' });
  if (!roleCheck.allowed) {
    sessions.delete(s.sid);
    setCookie(res, 'mdt_session', '', 0);
    return send(res, 403, { error: 'role_denied' });
  }
  if (req.headers['x-mdt'] !== '1' || !String(req.headers['content-type'] || '').startsWith('application/json')) return send(res, 400, { error: 'bad_request' });
  if (limited(s.d)) return send(res, 429, { error: 'rate' });
  let data;
  try { data = JSON.parse(await readBody(req)); } catch { return send(res, 400, { error: 'bad_request' }); }
  if (!data || typeof data !== 'object' || Array.isArray(data) || typeof data.action !== 'string' || !/^[A-Za-z]{1,40}$/.test(data.action)) return send(res, 400, { error: 'bad_request' });
  let reply;
  try {
    const started = Date.now();
    const r = await fetch(cfg.fivemUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-mdt-secret': cfg.fivemSecret },
      body: JSON.stringify({ discord: s.d, webAdmin: s.webAdmin === true, action: data.action, payload: data.payload && typeof data.payload === 'object' && !Array.isArray(data.payload) ? data.payload : {} }),
      signal: AbortSignal.timeout(10_000),
    });
    const elapsed = Date.now() - started;
    if (elapsed >= 1500) console.warn(`[p_mdt_web] Trage FiveM-reactie: actie=${data.action}, duur=${elapsed}ms`);
    if (!r.ok) {
      const errors = { 401: 'bad_secret', 403: 'server_ip_blocked', 404: 'api_not_found', 503: 'resource_not_configured' };
      return send(res, 502, { error: errors[r.status] || 'fivem_http_error', httpStatus: r.status });
    }
    reply = await r.json();
  } catch (e) {
    return send(res, 502, { error: e && (e.name === 'TimeoutError' || e.name === 'AbortError') ? 'fivem_timeout' : 'server_unreachable' });
  }
  if (!reply || reply.ok !== true) {
    const err = reply && reply.error;
    if (err === 'offline') return send(res, 409, { error: 'offline' });
    if (err === 'not_authorized') return send(res, 409, { error: 'denied' });
    if (err === 'denied') return send(res, 403, { error: 'denied' });
    return send(res, 502, { error: err || 'server_error' });
  }
  send(res, 200, reply.result === undefined ? null : reply.result);
}

// --- statische bestanden ----------------------------------------------------------------
const PUBLIC = path.join(__dirname, 'public');
const TYPES = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
function serveStatic(req, res, pathname) {
  const rel = pathname === '/' ? '/index.html' : pathname;
  const file = path.normalize(path.join(PUBLIC, rel));
  if (!file.startsWith(PUBLIC + path.sep)) return send(res, 403, 'Verboden');
  fs.readFile(file, (err, buf) => {
    if (err) return send(res, 404, 'Niet gevonden');
    const etag = `W/\"${crypto.createHash('sha256').update(buf).digest('base64url')}\"`;
    const isHtml = path.extname(file) === '.html';
    const headers = {
      ...SECURITY_HEADERS,
      'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream',
      'Cache-Control': isHtml ? 'no-cache' : 'public, max-age=300, must-revalidate',
      ETag: etag,
    };
    if (req.headers['if-none-match'] === etag) {
      res.writeHead(304, headers);
      return res.end();
    }
    res.writeHead(200, headers);
    res.end(req.method === 'HEAD' ? undefined : buf);
  });
}

// --- server -------------------------------------------------------------------------------
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, cfg.publicUrl);
    const p = url.pathname;
    if ((req.method === 'GET' || req.method === 'HEAD') && p === '/healthz') return send(res, 200, { ok: true, service: 'p_mdt_web', publicUrlConfigured: !loopbackHost, fiveMEndpointConfigured: !!cfg.fivemUrl });
    if (req.method === 'GET' && p === '/auth/login') return login(req, res);
    if (req.method === 'GET' && p === '/auth/callback') return await callback(req, res, url);
    if (req.method === 'POST' && p === '/auth/logout') {
      if (req.headers['x-mdt'] !== '1') return send(res, 400, { error: 'bad_request' });
      const s = session(req);
      if (s) sessions.delete(s.sid);
      setCookie(res, 'mdt_session', '', 0);
      return send(res, 200, { ok: true });
    }
    if (req.method === 'GET' && p === '/api/me') {
      const s = session(req);
      if (!s) return send(res, 200, { loggedIn: false });
      const roleCheck = await checkDiscordRoles(s);
      if (roleCheck.unavailable) return send(res, 503, { error: 'role_check_unavailable' });
      if (!roleCheck.allowed) {
        sessions.delete(s.sid);
        setCookie(res, 'mdt_session', '', 0);
        return send(res, 200, { loggedIn: false, roleDenied: true });
      }
      return send(res, 200, { loggedIn: true, username: s.u, discord: { id: s.d, username: s.handle || s.u, displayName: s.u, avatar: s.avatar || '', nickname: s.guildNickname || '', rank: cfg.rankNames[s.rank] || '', admin: s.webAdmin === true } });
    }
    if (req.method === 'POST' && p === '/api') return await api(req, res);
    if (req.method === 'GET' || req.method === 'HEAD') return serveStatic(req, res, p);
    send(res, 405, 'Niet toegestaan');
  } catch (e) {
    console.error(e);
    if (!res.headersSent) send(res, 500, 'Serverfout');
  }
});
server.listen(cfg.port, cfg.host, () => console.log(`p_mdt_web draait op http://${cfg.host}:${cfg.port} (publiek: ${cfg.publicUrl})`));
