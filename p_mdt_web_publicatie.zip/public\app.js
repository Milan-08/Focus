﻿'use strict';

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const newRequestId = () => window.crypto?.randomUUID ? window.crypto.randomUUID() : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => { const r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16); });

const state = { view: 'dashboard', viewArg: null, me: null, discord: null, profile: null, reportTypes: [], canDelete: false, canManage: false, canReview: false, canLicence: false, isJustice: false, caseStatuses: [], caseTemplates: [], calls: [], callQuery: '', callStatusFilter: '', callPriorityFilter: '', callCodeFilter: '' };
let deferredDataRefresh = false;

const TITLES = {
  dashboard: 'Overzicht', citizens: 'Burgers', vehicles: 'Voertuigen', reports: 'Rapporten',
  wanted: 'Gezocht', dispatch: 'Meldingen', officers: 'Agenten', cases: 'Zaken', charges: 'Strafwetboek',
  sentences: 'Vonnissen',
  audit: 'Logboek',
};
const GROUPS = {
  operations: { title: 'Operationeel', caption: 'Actuele inzet en bezetting' },
  files: { title: 'Dossiers', caption: 'Rapporten en zaakbeheer' },
  search: { title: 'Opzoeken', caption: 'Raadpleeg beschikbare registraties' },
  justice: { title: 'Justitie', caption: 'Wetboek en afhandeling' },
};
let activeGroup = 'operations';

function syncNavigation(group = activeGroup) {
  activeGroup = GROUPS[group] ? group : 'operations';
  const meta = GROUPS[activeGroup];
  if ($('#sideTitle')) $('#sideTitle').textContent = meta.title;
  if ($('#sideCaption')) $('#sideCaption').textContent = meta.caption;
  $$('#railNav button[data-group]').forEach((b) => {
    const active = b.dataset.group === activeGroup;
    b.classList.toggle('active', active);
    if (active) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
    b.classList.toggle('hidden', !$$(`#nav button[data-group="${b.dataset.group}"]`).some((item) => !item.classList.contains('role-hidden')));
  });
  $$('#nav button[data-view]').forEach((b) => b.classList.toggle('hidden', b.dataset.group !== activeGroup || b.classList.contains('role-hidden')));
}

// Toont enkel de menu-items die bij de rol van de gebruiker horen.
function applyRole() {
  const hidden = new Set();
  if (!state.canReview) hidden.add('sentences');
  if (!state.canManage) hidden.add('audit');
  if (state.isJustice) ['dispatch', 'officers'].forEach((v) => hidden.add(v));
  $$('#nav button[data-view]').forEach((b) => b.classList.toggle('role-hidden', hidden.has(b.dataset.view)));
  syncNavigation(activeGroup);
}

// --- helpers -----------------------------------------------------------
let sessionGone = false;
function setConnectionStatus(online) {
  const el = $('#connectionStatus');
  if (!el) return;
  el.classList.toggle('offline', !online);
  const text = el.querySelector('span');
  if (text) text.textContent = online ? 'Verbonden' : 'Geen verbinding';
}
async function api(action, payload = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15_000);
  try {
    const r = await fetch('/api', {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'X-MDT': '1' },
      body: JSON.stringify({ action, payload }), signal: controller.signal,
    });
    if (r.status === 401) { showScreen('login'); return null; }
    if (r.status === 409) {
      const e = await r.json().catch(() => ({}));
      setConnectionStatus(e.error !== 'offline');
      showScreen(e.error === 'offline' ? 'offline' : 'denied');
      return null;
    }
    if (r.status === 403) {
      const e = await r.json().catch(() => ({}));
      if (e.error === 'role_denied') { showScreen('roleDenied'); return null; }
      setConnectionStatus(true);
      return { ok: false, error: e.error === 'denied' ? 'Je Discord-rang of MDT-rang heeft geen rechten voor deze actie. Vernieuw de pagina na het bijwerken van de p_mdt-resource.' : 'Geen toestemming voor deze actie.' };
    }
    if (!r.ok) {
      setConnectionStatus(false);
      const e = await r.json().catch(() => ({}));
      const reasons = {
        api_not_found: 'De FiveM-host antwoordt, maar de MDT-API geeft 404. Controleer of de nieuwste p_mdt-resource draait en of de ingestelde HTTP-poort klopt.',
        bad_secret: 'De website en p_mdt gebruiken niet dezelfde geheime koppelsleutel. Zet dezelfde sleutel in beide instellingen.',
        resource_not_configured: 'Websitekoppeling staat uit in p_mdt. Stel Config.Web.Secret in en herstart de resource.',
        server_ip_blocked: 'De FiveM-server weigert de websiteverbinding. Controleer Config.Web.AllowedIp en de firewall.',
        fivem_timeout: 'De FiveM-server antwoordt niet binnen 10 seconden. Controleer het HTTP-adres, de poort en de hostingfirewall.',
        server_unreachable: 'De website kan geen verbinding maken met de FiveM HTTP-poort. Controleer het publieke adres, de poort en de firewall.',
      };
      return { ok: false, error: reasons[e.error] || `De serververbinding mislukte${e.httpStatus ? ` (HTTP ${e.httpStatus})` : ''}. Controleer de FiveM-koppeling.` };
    }
    const result = await r.json();
    setConnectionStatus(true);
    return result;
  } catch (e) { setConnectionStatus(false); return { ok: false, error: e?.name === 'AbortError' ? 'De website vroeg te lang op antwoord. Controleer je internetverbinding en probeer opnieuw.' : 'De website kon de aanvraag niet versturen. Controleer je verbinding en probeer opnieuw.' }; }
  finally { clearTimeout(timer); }
}
async function logout() {
  await fetch('/auth/logout', { method: 'POST', headers: { 'X-MDT': '1' } }).catch(() => {});
  location.reload();
}

// Schermen buiten de MDT zelf: inloggen, personage offline, geen toegang
function showScreen(name) {
  if (sessionGone && name !== 'login') return;
  const texts = {
    login: ['FOCUS', 'Log in met Discord om verder te gaan.', '<a class="btn" href="/auth/login">Inloggen met Discord</a>'],
    offline: ['Je personage is niet online', 'Start het spel en laad je agent in, met hetzelfde Discord-account. Daarna kan je hier verder.', '<button class="btn" id="retry">Opnieuw proberen</button> <button class="btn ghost" id="logoutBtn">Uitloggen</button>'],
    denied: ['Geen toegang', 'Je personage is niet in dienst of heeft geen toegang tot de MDT. Ga in dienst en probeer opnieuw.', '<button class="btn" id="retry">Opnieuw proberen</button> <button class="btn ghost" id="logoutBtn">Uitloggen</button>'],
    roleDenied: ['Geen toegang', 'Je Discord-account heeft geen toegestane politierol meer. Alleen leden met een ingestelde politierol kunnen de MDT gebruiken.', '<a class="btn" href="/auth/login">Opnieuw aanmelden</a> <button class="btn ghost" id="logoutBtn">Uitloggen</button>'],
  };
  const t = texts[name];
  if (name === 'login') sessionGone = true;
  $('#app').classList.add('hidden');
  const el = $('#gate');
  el.classList.remove('hidden');
  el.innerHTML = `<div class="gate-card"><div class="badge-big" aria-hidden="true"><img class="police-logo" src="police-logo.png" alt=""></div><h1>${t[0]}</h1><p>${t[1]}</p><div class="row" style="justify-content:center">${t[2]}</div></div>`;
  const rt = $('#retry'); if (rt) rt.onclick = () => location.reload();
  const lo = $('#logoutBtn'); if (lo) lo.onclick = logout;
}
const fmtDate = (ts) => {
  if (!ts) return '-';
  const d = new Date(Number(ts) * 1000);
  return d.toLocaleString('nl-BE', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
};
const ago = (ts) => {
  const s = Math.max(0, Math.floor(Date.now() / 1000 - ts));
  if (s < 60) return 'zonet';
  if (s < 3600) return `${Math.floor(s / 60)} min geleden`;
  return `${Math.floor(s / 3600)} u geleden`;
};
const money = (n) => '€ ' + Number(n || 0).toLocaleString('nl-BE');
let toastTimer;
function toast(msg, err) {
  const t = $('#toast');
  t.textContent = msg; t.className = 'toast' + (err ? ' err' : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.add('hidden'), 2800);
}
function debounce(fn, ms = 300) {
  let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

// --- modal -------------------------------------------------------------
function openModal(html) { $('#modalCard').innerHTML = html; $('#modal').classList.remove('hidden'); }
function closeModal() {
  $('#modal').classList.add('hidden'); $('#modalCard').innerHTML = '';
  if (deferredDataRefresh) {
    deferredDataRefresh = false;
    toast('Gegevens bijgewerkt door een collega.');
    setTimeout(refreshCurrentView, 0);
  }
}
$('#modal').addEventListener('mousedown', (e) => { if (e.target.id === 'modal') closeModal(); });

// --- navigation --------------------------------------------------------
function go(view, arg) {
  state.view = view;
  state.viewArg = arg ?? null;
  const link = $(`#nav button[data-view="${view}"]`);
  syncNavigation(link?.dataset.group || activeGroup);
  $$('#nav button').forEach((b) => {
    const active = b.dataset.view === view;
    b.classList.toggle('active', active);
    if (active) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
  });
  $('#title').textContent = TITLES[view] || '';
  const fn = VIEWS[view];
  $('#view').innerHTML = '<div class="empty">Laden...</div>';
  if (fn) fn(arg);
}
function refreshCurrentView() {
  if (sessionGone || $('#app').classList.contains('hidden')) return;
  if (!$('#modal').classList.contains('hidden')) { deferredDataRefresh = true; return; }
  if (state.viewArg && state.view === 'citizens') return showCitizen(state.viewArg);
  if (state.viewArg && state.view === 'vehicles') return showVehicle(state.viewArg);
  const search = $('#q') || $('#auditQ') || $('#chargeFilter');
  if (search) { search.dispatchEvent(new Event('input')); return; }
  go(state.view, state.viewArg);
}
$('#nav').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-view]');
  if (b) go(b.dataset.view);
});
$('#railNav').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-group]');
  if (!b || b.classList.contains('hidden')) return;
  const links = $$(`#nav button[data-group="${b.dataset.group}"]`).filter((item) => !item.classList.contains('role-hidden'));
  const current = links.find((item) => item.dataset.view === state.view);
  const target = current || links[0];
  if (target) go(target.dataset.view);
});
$('#closeBtn').addEventListener('click', logout);
$('#settingsButton').addEventListener('click', openProfileSettings);
$('#profileButton').addEventListener('click', openProfileSettings);
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  if (!$('#modal').classList.contains('hidden')) closeModal();
});

// --- reusable bits -----------------------------------------------------
const reportRow = (r) => `
  <div class="item click" data-report="${esc(r.id)}">
    <div class="t">#${esc(r.id)} &middot; ${esc(r.title)}</div>
    <div class="m"><span class="tag">${esc(r.type)}</span>${r.officer_name ? esc(r.officer_name) + ' &middot; ' : ''}${fmtDate(r.created_at)}</div>
  </div>`;

const caseRow = (c) => `
  <div class="item click case-row" data-case="${esc(c.id)}">
    <span class="case-number">#${esc(c.id)}</span><div class="case-summary"><div class="t">${esc(c.title)}</div>
    ${c.officer_name ? `<div class="m">${esc(c.officer_name)} &middot; Laatst bijgewerkt ${fmtDate(c.updated_at)}</div>` : ''}</div><span class="tag">${esc(c.status)}</span>
  </div>`;

const STATUS_CLASS = { actief: 'status-pending', bevestigd: 'status-confirmed', verlaagd: 'status-reduced', ingetrokken: 'red' };

function recordRow(r) {
  const status = r.status || 'actief';
  const reduced = r.original_fine != null && Number(r.original_fine) !== Number(r.fine);
  return `<div class="item"><div class="row spread"><div class="t">${r.charges.map((c) => esc(c.label)).join(', ') || 'Onbekend'}</div>
      <span class="tag ${STATUS_CLASS[status] || ''}">${esc(status)}</span></div>
    <div class="m">Boete ${reduced ? `<s>${money(r.original_fine)}</s> ` : ''}${money(r.fine)} ${r.fine > 0 ? (r.invoiced ? '<span class="tag green">gefactureerd</span>' : '<span class="tag red">niet gefactureerd</span>') : ''}
    &middot; ${esc(r.jail)} maanden cel${Number(r.points) > 0 ? ` &middot; ${esc(r.points)} punten` : ''} &middot; ${esc(r.officer_name)} &middot; ${fmtDate(r.created_at)}
    ${r.report_id ? `<span class="tag" data-report="${esc(r.report_id)}" style="cursor:pointer;margin-left:6px">rapport #${esc(r.report_id)}</span>` : ''}
    ${state.canManage ? `<a href="#" data-delrec="${r.id}" style="color:#ffb4b6;margin-left:8px">verwijder</a>` : ''}</div>
    ${r.note ? `<div class="m">${esc(r.note)}</div>` : ''}
    ${r.reviewed_by ? `<div class="m">Beoordeeld door ${esc(r.reviewed_by)}${r.review_note ? ': ' + esc(r.review_note) : ''}</div>` : ''}</div>`;
}

function bindClicks(root) {
  const bind = (selector, fn) => $$(selector, root).forEach((el) => {
    el.addEventListener('click', fn);
    if (el.tagName !== 'A' && !el.hasAttribute('tabindex')) {
      el.tabIndex = 0;
      el.setAttribute('role', 'button');
      el.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); el.click(); }
      });
    }
  });
  bind('[data-case]', (e) => openCase(e.currentTarget.dataset.case));
  bind('[data-report]', (e) => openReport(e.currentTarget.dataset.report));
  bind('[data-citizen]', (e) => go('citizens', e.currentTarget.dataset.citizen));
  bind('[data-plate]', (e) => go('vehicles', e.currentTarget.dataset.plate));
}

function searchBar(placeholder, onInput, extra = '') {
  const v = $('#view');
  v.innerHTML = `<div class="row" style="margin-bottom:14px"><input id="q" class="grow" placeholder="${esc(placeholder)}" autocomplete="off">${extra}</div><div id="results" class="list"></div>`;
  const q = $('#q');
  q.setAttribute('aria-label', placeholder);
  let generation = 0, timer;
  q.addEventListener('input', () => {
    const current = ++generation;
    clearTimeout(timer);
    timer = setTimeout(() => {
      if (generation === current && $('#q') === q) onInput(q.value.trim(), () => generation === current && $('#q') === q);
    }, 300);
  });
  q.focus();
  return q;
}

// --- views -------------------------------------------------------------
const VIEWS = {};

VIEWS.dashboard = async () => {
  const d = await api('dashboard');
  if (!d || d.ok === false) {
    const message = d?.error || 'De MDT-server heeft niet op tijd geantwoord.';
    const detail = message;
    $('#view').innerHTML = `<div class="box connection-error"><span class="eyebrow">MDT-SERVER NIET BEREIKBAAR</span><h3>Overzicht kon niet worden geladen</h3><p>${esc(detail)}</p><button class="btn" id="retryDashboard">Opnieuw proberen</button></div>`;
    $('#retryDashboard').onclick = () => go('dashboard');
    return;
  }
  state.me = d.officer; state.reportTypes = d.reportTypes || []; state.canDelete = !!d.officer.canDelete || !!state.discord?.admin; state.canManage = !!d.officer.canManage || !!state.discord?.admin;
  state.caseStatuses = d.caseStatuses || []; state.caseTemplates = d.caseTemplates || [];
  state.canReview = !!d.officer.canReview; state.canLicence = !!d.officer.canLicence; state.isJustice = !!d.officer.isJustice;
  applyProfile(d.profile || {});
  applyRole();
  renderMe();
  const officers = d.officers || [];
  const activeCalls = d.activeCalls || state.calls || [];
  $('#view').innerHTML = `
    <div class="briefing"><div><span class="eyebrow">OPERATIONEEL OVERZICHT</span><h2>Goedendag, ${esc(state.profile.displayName || d.officer.name || 'agent')}</h2><p>${esc(d.officer.job || 'Politie')} ${d.officer.callsign && d.officer.callsign !== 'N/A' ? `&middot; Roepnummer ${esc(d.officer.callsign)}` : ''} &middot; Dit is je actuele werkoverzicht.</p></div><div class="briefing-mark"><img src="focus-logo.png" alt="FOCUS"></div></div>
    <div class="cards">
      <button class="stat stat-link" data-go="officers"><b>${Number(d.stats.officers) || 0}</b><span>Agenten in dienst</span><small>Bekijk bezetting <b>→</b></small></button>
      <button class="stat stat-link" data-go="dispatch"><b>${Number(d.stats.calls) || 0}</b><span>Actieve meldingen</span><small>Open meldkamer <b>→</b></small></button>
      <button class="stat stat-link" data-go="wanted"><b>${Number(d.stats.wanted) || 0}</b><span>Actieve opsporingen</span><small>Bekijk opsporingen <b>→</b></small></button>
      <button class="stat stat-link" data-go="reports"><b>${Number(d.stats.reports) || 0}</b><span>Opgestelde rapporten</span><small>Open rapporten <b>→</b></small></button>
    </div>
    <div class="dispatch-summary" aria-label="Statusoverzicht meldkamer"><span><i class="summary-dot new"></i><b>${Number(d.stats.callsNew) || 0}</b> nieuw</span><span><i class="summary-dot accepted"></i><b>${Number(d.stats.callsAccepted) || 0}</b> aangenomen</span><span><i class="summary-dot enroute"></i><b>${Number(d.stats.callsEnroute) || 0}</b> onderweg</span><span><i class="summary-dot onscene"></i><b>${Number(d.stats.callsOnscene) || 0}</b> ter plaatse</span><button class="btn ghost small" data-go="dispatch">Meldkamer openen →</button></div>
    <div class="dashboard-grid"><div class="dashboard-main">
      <div class="box"><div class="row spread"><div><span class="eyebrow">TEAMUPDATE</span><h3>Mededelingen</h3></div>${state.canManage ? '<button class="btn small" id="newAnn">+ Mededeling</button>' : '<span class="tag">Beheerrechten vereist om te plaatsen</span>'}</div>
        <div class="list">${(d.announcements || []).map(annRow).join('') || '<div class="empty">Er zijn momenteel geen mededelingen.</div>'}</div></div>
      <div class="box"><div class="row spread"><h3>Laatste rapporten</h3><button class="btn ghost small" data-go="reports">Alle rapporten</button></div><div class="list">${d.recentReports.map(reportRow).join('') || '<div class="empty">Er zijn nog geen rapporten opgesteld.</div>'}</div></div>
      <div class="box"><div class="row spread"><h3>Actieve opsporingen</h3><button class="btn ghost small" data-go="wanted">Overzicht</button></div><div class="list">${d.wanted.map((w) => `
        <div class="item click" ${w.kind === 'citizen' ? `data-citizen="${esc(w.identifier)}"` : `data-plate="${esc(w.identifier)}"`}>
          <div class="t">${esc(w.label)} <span class="tag red">${w.kind === 'citizen' ? 'Persoon' : 'Voertuig'}</span></div>
          <div class="m">${esc(w.reason)}</div></div>`).join('') || '<div class="empty">Er staan geen actieve opsporingen open.</div>'}</div></div>
    </div><aside class="dashboard-side">
      <div class="box duty-panel"><div class="row spread"><div><span class="eyebrow">LIVE BEZETTING</span><h3>Agenten in dienst</h3></div><span class="tag green">${officers.length} online</span></div>
        <div class="list">${officers.slice(0, 8).map((o) => `<div class="duty-person"><span class="duty-dot"></span><div class="grow"><b>${esc(o.name)}</b><small>${esc(o.job)}${o.grade ? ` &middot; ${esc(o.grade)}` : ''} · ${esc(radioStatusName(o.statusCode))}</small></div><span class="tag">${esc(o.callsign || '—')}</span></div>`).join('') || '<div class="empty">Er zijn momenteel geen agenten in dienst.</div>'}</div>
        ${officers.length > 8 ? `<button class="btn ghost small duty-more" data-go="officers">Bekijk alle ${officers.length} agenten</button>` : ''}</div>
      <div class="box"><div class="row spread"><h3>Actieve meldingen</h3><button class="btn ghost small" data-go="dispatch">Meldkamer</button></div><div class="list">${activeCalls.slice(0, 4).map((c) => `<button class="item click call-preview" data-go="dispatch"><span class="call-preview-tags"><span class="tag red">${esc(c.code || 'MELDING')}</span><span class="tag ${priorityClass(c.priority)}">P${Number(c.priority) || 2}</span><span class="tag call-status ${callStatusClass(c.status)}">${CALL_STATUS_LABELS[c.status] || 'Nieuw'}</span></span><span class="t">${esc(c.title || 'Melding')}</span><span class="m">${esc(c.street || 'Locatie onbekend')}</span></button>`).join('') || '<div class="empty">Geen actieve meldingen.</div>'}</div></div>
      <div class="quick-links"><span class="eyebrow">SNELLE ACTIES</span>${!state.isJustice ? '<button class="btn" id="dashboardNewCall">+ Nieuwe melding</button><button class="btn ghost" id="dashboardNewReport">+ Rapport opstellen</button>' : ''}<button class="btn ghost" data-go="cases">Dossiers openen</button></div>
    </aside></div>`;
  bindClicks($('#view'));
  $$('[data-go]').forEach((b) => b.onclick = () => go(b.dataset.go));
  const na = $('#newAnn'); if (na) na.onclick = openAnnouncementModal;
  const nc = $('#dashboardNewCall'); if (nc) nc.onclick = openCallModal;
  const nr = $('#dashboardNewReport'); if (nr) nr.onclick = () => openReportEditor(null);
  $$('[data-delann]').forEach((b) => b.onclick = async () => { await api('announcementDelete', { id: b.dataset.delann }); go('dashboard'); });
};

function annRow(n) {
  return `<div class="item"><div class="row spread"><div class="t">${esc(n.title)}</div>
    ${state.canManage ? `<a href="#" data-delann="${n.id}" onclick="return false" style="color:#ffb4b6;font-size:12px">verwijder</a>` : ''}</div>
    <div style="margin-top:4px;white-space:pre-wrap">${esc(n.message)}</div>
    <div class="m">${esc(n.officer_name)} &middot; ${fmtDate(n.created_at)}</div></div>`;
}

function openAnnouncementModal() {
  openModal(`<h2>Nieuwe mededeling</h2>
    <label>Titel</label><input id="aTitle" maxlength="120" placeholder="Bijv. Briefing vanavond">
    <label>Bericht</label><textarea id="aMsg" maxlength="2000" style="min-height:120px" placeholder="Deel een update met het politieteam…"></textarea>
    <div class="row spread" style="margin-top:18px"><button class="btn ghost" id="aCancel">Annuleren</button><button class="btn" id="aSave">Plaatsen</button></div>`);
  $('#aCancel').onclick = closeModal;
  $('#aSave').onclick = async () => {
    const r = await api('announcementAdd', { title: $('#aTitle').value, message: $('#aMsg').value });
    if (r && r.ok) { toast('Mededeling geplaatst'); closeModal(); go('dashboard'); } else toast((r && r.error) || 'Mededeling niet geplaatst. Controleer je verbinding en beheerdersrang.', true);
  };
}

// Burgers
VIEWS.citizens = (cid) => {
  if (cid) return showCitizen(cid);
  searchBar('Zoek op naam of burger-ID...', async (q, isCurrent) => {
    let res = $('#results');
    if (!res) return;
    if (q.length < 2) return res.innerHTML = '<div class="empty">Typ minstens 2 tekens</div>';
    res.innerHTML = '<div class="empty">Zoeken...</div>';
    const rows = await api('citizenSearch', { query: q });
    if (!isCurrent()) return;
    if (!rows) return res.innerHTML = '<div class="empty">Zoeken is niet gelukt. Controleer de verbinding en probeer opnieuw.</div>';
    res = $('#results'); if (!res) return;
    res.innerHTML = rows.map((c) => `
      <div class="item click" data-citizen="${esc(c.citizenid)}">
        <div class="t">${esc(c.name)}</div><div class="m">${esc(c.citizenid)} &middot; geboren ${esc(c.birthdate || '?')}</div>
      </div>`).join('') || '<div class="empty">Geen resultaten</div>';
    bindClicks(res);
  });
  $('#results').innerHTML = '<div class="empty">Zoek een burger</div>';
};

async function showCitizen(cid) {
  const c = await api('citizenGet', { citizenid: cid });
  if (!c) return $('#view').innerHTML = '<div class="empty">Burger niet gevonden.</div>';
  const wanted = c.wanted.length > 0;
  const genderLabel = c.gender === 0 || c.gender === '0' ? 'Man' : c.gender === 1 || c.gender === '1' ? 'Vrouw' : (c.gender ?? '-');
  $('#view').innerHTML = `
    <div class="row spread" style="margin-bottom:14px">
      <button class="btn ghost small" id="back">&larr; Terug</button>
      ${state.isJustice ? '' : `<div class="row">
        <button class="btn small" id="newArrest">Aanhouding registreren</button>
        <button class="btn small" id="newSentence">Straf opleggen</button>
        <button class="btn small" id="newReport">Rapport aanmaken</button>
        <button class="btn danger small" id="markWanted">Als gezocht melden</button>
      </div>`}
    </div>
    ${wanted ? `<div class="banner"><strong>GEZOCHT</strong> &mdash; ${c.wanted.map((w) => esc(w.reason)).join(' | ')}
      ${c.wanted.map((w) => `<button class="btn small" style="margin-left:10px" data-resolve="${w.id}">Opheffen</button>`).join('')}</div>` : ''}
    <div class="profile">
      ${c.mugshot ? `<img class="avatar" src="${esc(c.mugshot)}" alt="">` : `<div class="avatar">${esc((c.name[0] || '?'))}</div>`}
      <div>
        <h2 style="margin:0 0 6px">${esc(c.name)}</h2>
        <div class="kv">
          <span>Burger-ID</span><span>${esc(c.citizenid)}</span>
          <span>Geboortedatum</span><span>${esc(c.birthdate || '-')}</span>
          <span>Geslacht</span><span>${esc(genderLabel)}</span>
          <span>Telefoon</span><span>${esc(c.phone || '-')}</span>
          <span>Nationaliteit</span><span>${esc(c.nationality || '-')}</span>
        </div>
        ${state.isJustice ? '' : '<a href="#" id="setPhoto" style="font-size:12px;color:var(--muted);display:inline-block;margin-top:6px">Foto wijzigen</a>'}
      </div>
    </div>
    <div class="box" style="margin-bottom:14px"><div class="row spread"><h3>Vergunningen en rijbewijspunten</h3></div>
      <div class="licenses">
        ${c.licenceTypes.map((t) => {
          const on = !!c.licences[t.key];
          return `<div class="license ${on ? 'valid' : 'none'}"><b>${esc(t.label)}</b><small>${on ? 'Geldig' : 'Niet in bezit of ingetrokken'}</small>
            ${state.canLicence ? `<div style="margin-top:6px"><button class="btn small ${on ? 'danger' : 'ok'}" data-lic="${esc(t.key)}" data-on="${on ? 1 : 0}">${on ? 'Intrekken' : 'Toekennen'}</button></div>` : ''}</div>`;
        }).join('')}
        <div class="license ${c.points <= 0 ? 'revoked' : c.points <= 3 ? 'suspended' : 'valid'}"><b>Punten: ${esc(c.points)}</b><small>Resterend op het rijbewijs</small>
          <div class="points">${Array.from({ length: Math.max(c.maxPoints || 12, c.points) }, (_, i) => `<i class="${i < (c.maxPoints || 12) - c.points ? 'on' : ''}"></i>`).join('')}</div>
          ${state.canLicence ? '<div style="margin-top:6px"><button class="btn ghost small" id="editPoints">Aanpassen</button></div>' : ''}</div>
      </div></div>
    <div class="grid2">
      <div>
        <div class="box"><h3>Voertuigen (${c.vehicles.length})</h3><div class="list">${c.vehicles.map((v) => `
          <div class="item click" data-plate="${esc(v.plate)}"><div class="t">${esc(v.plate)}</div><div class="m">${esc(v.vehicle)}</div></div>`).join('') || '<div class="empty">Geen voertuigen</div>'}</div></div>
        <div class="box"><h3>Aanhoudingen (${c.arrests.length})</h3><div class="list">${c.arrests.map(arrestRow).join('') || '<div class="empty">Geen aanhoudingen</div>'}</div></div>
        <div class="box"><h3>Strafblad (${c.records.length})</h3><div class="list">${c.records.map(recordRow).join('') || '<div class="empty">Geen straffen</div>'}</div></div>
        <div class="box"><h3>Eerdere vonnissen (${c.judgements.length})</h3><div class="list">${c.judgements.map(judgementRow).join('') || '<div class="empty">Geen vonnissen</div>'}</div></div>
      </div>
      <div>
        <div class="box"><h3>Notities</h3>
          ${state.isJustice ? '' : '<div class="row"><input id="noteText" class="grow" placeholder="Nieuwe notitie..."><button class="btn small" id="addNote">Toevoegen</button></div>'}
          <div class="list" style="margin-top:10px">${c.notes.map((n) => `
            <div class="item"><div>${esc(n.note)}</div><div class="m">${esc(n.officer_name)} &middot; ${fmtDate(n.created_at)}
            ${state.isJustice ? '' : `<a href="#" data-delnote="${n.id}" style="color:#ffb4b6;margin-left:8px">verwijder</a>`}</div></div>`).join('') || '<div class="empty">Geen notities</div>'}</div>
        </div>
        <div class="box"><h3>Rapporten (${c.reports.length})</h3><div class="list">${c.reports.map(reportRow).join('') || '<div class="empty">Geen rapporten</div>'}</div></div>
        <div class="box"><h3>Zaken (${c.cases.length})</h3><div class="list">${c.cases.map(caseRow).join('') || '<div class="empty">Geen zaken</div>'}</div></div>
      </div>
    </div>`;
  const root = $('#view');
  bindClicks(root);
  if (!state.isJustice) {
    $('#newSentence').onclick = () => openSentenceModal(c, () => showCitizen(cid));
    $('#newArrest').onclick = () => openArrestModal(c, () => showCitizen(cid));
    $('#setPhoto').onclick = (e) => { e.preventDefault(); openPhotoModal(c, () => showCitizen(cid)); };
  }
  $$('[data-lic]', root).forEach((b) => b.addEventListener('click', () => openLicenceModal(c, b.dataset.lic, b.dataset.on !== '1', () => showCitizen(cid))));
  const ep = $('#editPoints'); if (ep) ep.onclick = () => openPointsModal(c, () => showCitizen(cid));
  $$('[data-delarrest]', root).forEach((x) => x.addEventListener('click', async (e) => {
    e.preventDefault();
    if (!confirm('Deze aanhouding verwijderen?')) return;
    const r = await api('arrestDelete', { id: x.dataset.delarrest });
    if (r && !r.ok) toast(r.error || 'Mislukt', true);
    showCitizen(cid);
  }));
  $$('[data-delrec]', root).forEach((x) => x.addEventListener('click', async (e) => {
    e.preventDefault();
    if (!confirm('Dit item uit het strafblad verwijderen?')) return;
    const r = await api('recordDelete', { id: x.dataset.delrec });
    if (r && !r.ok) toast(r.error || 'Mislukt', true);
    showCitizen(cid);
  }));
  $('#back').onclick = () => go('citizens');
  if (!state.isJustice) {
    $('#newReport').onclick = () => openReportEditor(null, { involved: [{ citizenid: c.citizenid, name: c.name }] });
    $('#markWanted').onclick = () => openWantedModal('citizen', c.citizenid, c.name, () => showCitizen(cid));
  }
  const addNote = $('#addNote');
  if (addNote) addNote.onclick = async () => {
    const note = $('#noteText').value.trim();
    if (!note) return;
    await api('noteAdd', { citizenid: cid, note });
    showCitizen(cid);
  };
  $$('[data-delnote]', root).forEach((a) => a.addEventListener('click', async (e) => {
    e.preventDefault();
    const r = await api('noteDelete', { id: a.dataset.delnote });
    if (r && !r.ok) toast(r.error || 'Mislukt', true);
    showCitizen(cid);
  }));
  $$('[data-resolve]', root).forEach((b) => b.addEventListener('click', async () => {
    await api('wantedResolve', { id: b.dataset.resolve });
    toast('Opsporing opgeheven');
    showCitizen(cid);
  }));
}

function judgementRow(j) {
  let offenses = j.offenses;
  try {
    const parsed = typeof offenses === 'string' ? JSON.parse(offenses) : offenses;
    if (Array.isArray(parsed)) offenses = parsed.map((o) => (typeof o === 'object' ? (o.label || o.name || JSON.stringify(o)) : o)).join(', ');
  } catch (e) { /* ruwe tekst tonen */ }
  return `<div class="item"><div class="t">${esc(offenses || 'Onbekend')}</div>
    <div class="m">Boete ${money(j.fine)} &middot; ${esc(j.jail || 0)} maanden cel &middot; Agent ${esc(j.officer || '?')} &middot; ${fmtDate(j.time > 1e11 ? j.time / 1000 : j.time)}</div></div>`;
}

// Voertuigen
VIEWS.vehicles = (plate) => {
  if (plate) return showVehicle(plate);
  searchBar('Zoek op nummerplaat...', async (q, isCurrent) => {
    let res = $('#results');
    if (!res) return;
    if (q.length < 2) return res.innerHTML = '<div class="empty">Typ minstens 2 tekens</div>';
    res.innerHTML = '<div class="empty">Zoeken...</div>';
    const rows = await api('vehicleSearch', { query: q });
    if (!isCurrent()) return;
    if (!rows) return res.innerHTML = '<div class="empty">Zoeken is niet gelukt. Controleer de verbinding en probeer opnieuw.</div>';
    res = $('#results'); if (!res) return;
    res.innerHTML = rows.map((v) => `
      <div class="item click" data-plate="${esc(v.plate)}">
        <div class="t">${esc(v.plate)} <span class="tag">${esc(v.model)}</span></div><div class="m">Eigenaar: ${esc(v.owner)}</div>
      </div>`).join('') || '<div class="empty">Geen resultaten</div>';
    bindClicks(res);
  });
  $('#results').innerHTML = '<div class="empty">Zoek een nummerplaat</div>';
};

async function showVehicle(plate) {
  const v = await api('vehicleGet', { plate });
  if (!v) return $('#view').innerHTML = '<div class="empty">Voertuig niet gevonden.</div>';
  const wanted = v.wanted.length > 0;
  $('#view').innerHTML = `
    <div class="row spread" style="margin-bottom:14px">
      <button class="btn ghost small" id="back">&larr; Terug</button>
      <div class="row"><button class="btn small" id="newReport">Rapport aanmaken</button>
      <button class="btn danger small" id="markWanted">Als gezocht melden</button></div>
    </div>
    ${wanted ? `<div class="banner"><strong>GEZOCHT</strong> &mdash; ${v.wanted.map((w) => esc(w.reason)).join(' | ')}
      ${v.wanted.map((w) => `<button class="btn small" style="margin-left:10px" data-resolve="${w.id}">Opheffen</button>`).join('')}</div>` : ''}
    <div class="box"><h3>${esc(v.plate)}</h3>
      <div class="kv"><span>Model</span><span>${esc(v.model)}</span>
      <span>Eigenaar</span><span><a href="#" data-citizen="${esc(v.citizenid)}" style="color:#93c5fd">${esc(v.owner)}</a></span></div></div>
    <div class="box"><h3>Rapporten (${v.reports.length})</h3><div class="list">${v.reports.map(reportRow).join('') || '<div class="empty">Geen rapporten</div>'}</div></div>
    <div class="box"><h3>Zaken (${v.cases.length})</h3><div class="list">${v.cases.map(caseRow).join('') || '<div class="empty">Geen zaken</div>'}</div></div>`;
  const root = $('#view');
  bindClicks(root);
  $$('a[data-citizen]', root).forEach((a) => a.addEventListener('click', (e) => e.preventDefault()));
  $('#back').onclick = () => go('vehicles');
  $('#newReport').onclick = () => openReportEditor(null, { plates: [v.plate] });
  $('#markWanted').onclick = () => openWantedModal('vehicle', v.plate, v.plate, () => showVehicle(plate));
  $$('[data-resolve]', root).forEach((b) => b.addEventListener('click', async () => {
    await api('wantedResolve', { id: b.dataset.resolve });
    toast('Opsporing opgeheven');
    showVehicle(plate);
  }));
}

// Rapporten
VIEWS.reports = () => {
  let offset = 0, version = 0, allRows = [];
  const q = searchBar('Zoek rapport (titel, nummer, agent, plaat)...', async (text) => {
    offset = 0; allRows = [];
    const current = ++version;
    const rows = await api('reportList', { query: text, offset });
    if (state.view !== 'reports' || current !== version) return;
    if (!rows) { const target = $('#results'); if (target) target.innerHTML = '<div class="empty">Rapporten laden is niet gelukt. Probeer opnieuw.</div>'; return; }
    allRows = rows;
    const res = $('#results');
    if (!res) return; // scherm is intussen gewisseld
    const draw = () => {
      res.innerHTML = allRows.map(reportRow).join('') || '<div class="empty">Geen rapporten</div>';
      if (rows.length === 50 && allRows.length >= offset + rows.length) res.innerHTML += '<button class="btn ghost load-more" id="reportMore">Meer rapporten laden</button>';
      bindClicks(res);
      const more = $('#reportMore', res);
      if (more) more.onclick = async () => {
        more.disabled = true; more.textContent = 'Laden…';
        const pageOffset = offset + 50, pageVersion = version;
        const next = await api('reportList', { query: q.value.trim(), offset: pageOffset });
        if (!next) { more.disabled = false; more.textContent = 'Opnieuw laden'; return; }
        if (state.view !== 'reports' || pageVersion !== version) return;
        offset = pageOffset; allRows = allRows.concat(next);
        draw();
      };
    };
    draw();
  }, '<button class="btn" id="newReport">+ Nieuw rapport</button>');
  $('#newReport').onclick = () => openReportEditor(null);
  q.dispatchEvent(new Event('input'));
};

async function openReport(id) {
  const r = await api('reportGet', { id });
  if (!r) return toast('Rapport niet gevonden', true);
  openModal(`
    <div class="row spread"><h2>#${esc(r.id)} &middot; ${esc(r.title)}</h2><span class="tag">${esc(r.type)}</span></div>
    <div class="m" style="color:var(--muted);font-size:12px;margin-bottom:12px">${esc(r.officer_name)} &middot; ${fmtDate(r.created_at)}${r.updated_at !== r.created_at ? ' (bewerkt ' + fmtDate(r.updated_at) + ')' : ''}</div>
    <div class="box"><pre class="desc">${esc(r.description)}</pre></div>
    ${r.involved.length ? `<div class="chips">${r.involved.map((p) => `<span class="chip" style="padding-right:10px;cursor:pointer" data-citizen="${esc(p.citizenid)}">${esc(p.name || p.citizenid)}</span>`).join('')}</div>` : ''}
    ${r.plates.length ? `<div class="chips">${r.plates.map((p) => `<span class="chip" style="padding-right:10px;cursor:pointer" data-plate="${esc(p)}">${esc(p)}</span>`).join('')}</div>` : ''}
    <div class="row spread" style="margin-top:18px">
      <div class="row"><button class="btn small" id="editRep">Bewerken</button>
      ${state.canDelete ? '<button class="btn danger small" id="delRep">Verwijderen</button>' : ''}</div>
      <button class="btn ghost small" id="closeM">Sluiten</button>
    </div>`);
  $('#closeM').onclick = closeModal;
  $$('#modalCard [data-citizen]').forEach((el) => el.addEventListener('click', () => { closeModal(); go('citizens', el.dataset.citizen); }));
  $$('#modalCard [data-plate]').forEach((el) => el.addEventListener('click', () => { closeModal(); go('vehicles', el.dataset.plate); }));
  $('#editRep').onclick = () => openReportEditor(r);
  const del = $('#delRep');
  if (del) del.onclick = async () => {
    if (!confirm('Dit rapport definitief verwijderen?')) return;
    const res = await api('reportDelete', { id: r.id });
    if (res && res.ok) { toast('Rapport verwijderd'); closeModal(); go(state.view); } else toast((res && res.error) || 'Mislukt', true);
  };
}

function openReportEditor(existing, prefill = {}) {
  const r = existing || { title: '', type: state.reportTypes[0] || 'Overig', description: '', involved: prefill.involved || [], plates: prefill.plates || [] };
  let involved = [...r.involved];
  let plates = [...r.plates];
  openModal(`
    <h2>${existing ? 'Rapport #' + esc(r.id) + ' bewerken' : 'Nieuw rapport'}</h2>
    <label>Titel</label><input id="rTitle" maxlength="120" value="${esc(r.title)}">
    <label>Type</label><select id="rType">${state.reportTypes.map((t) => `<option ${t === r.type ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select>
    <label>Beschrijving</label><textarea id="rDesc">${esc(r.description)}</textarea>
    <label>Betrokken personen</label>
    <input id="rPerson" placeholder="Zoek burger op naam of ID..." autocomplete="off">
    <div id="rSuggest" class="suggest hidden"></div>
    <div id="rPeople" class="chips"></div>
    <label>Nummerplaten (Enter om toe te voegen)</label>
    <input id="rPlate" placeholder="BV. ABC123" autocomplete="off">
    <div id="rPlates" class="chips"></div>
    <div class="row spread" style="margin-top:18px">
      <button class="btn ghost" id="rCancel">Annuleren</button>
      <button class="btn" id="rSave">Opslaan</button>
    </div>`);

  const drawChips = () => {
    $('#rPeople').innerHTML = involved.map((p, i) => `<span class="chip">${esc(p.name || p.citizenid)}<button data-rp="${i}">&times;</button></span>`).join('');
    $('#rPlates').innerHTML = plates.map((p, i) => `<span class="chip">${esc(p)}<button data-rl="${i}">&times;</button></span>`).join('');
    $$('[data-rp]').forEach((b) => b.onclick = () => { involved.splice(+b.dataset.rp, 1); drawChips(); });
    $$('[data-rl]').forEach((b) => b.onclick = () => { plates.splice(+b.dataset.rl, 1); drawChips(); });
  };
  drawChips();

  $('#rPerson').addEventListener('input', debounce(async () => {
    const q = $('#rPerson').value.trim(), box = $('#rSuggest');
    if (q.length < 2) return box.classList.add('hidden');
    const rows = await api('citizenSearch', { query: q }) || [];
    box.innerHTML = rows.map((c) => `<div data-cid="${esc(c.citizenid)}" data-name="${esc(c.name)}">${esc(c.name)} <span style="color:var(--muted)">${esc(c.citizenid)}</span></div>`).join('') || '<div>Geen resultaten</div>';
    box.classList.remove('hidden');
    $$('[data-cid]', box).forEach((el) => el.onclick = () => {
      if (!involved.some((p) => p.citizenid === el.dataset.cid)) involved.push({ citizenid: el.dataset.cid, name: el.dataset.name });
      $('#rPerson').value = ''; box.classList.add('hidden'); drawChips();
    });
  }));
  $('#rPlate').addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    const v = e.target.value.trim().toUpperCase();
    if (v && !plates.includes(v)) plates.push(v);
    e.target.value = ''; drawChips();
  });
  $('#rCancel').onclick = () => { closeModal(); };
  $('#rSave').onclick = async () => {
    const pending = $('#rPlate').value.trim().toUpperCase();
    if (pending && !plates.includes(pending)) plates.push(pending);
    const res = await api('reportSave', {
      id: existing ? existing.id : undefined,
      title: $('#rTitle').value, type: $('#rType').value, description: $('#rDesc').value, involved, plates,
    });
    if (res && res.ok) { toast('Rapport opgeslagen'); closeModal(); if (state.view === 'reports' || state.view === 'dashboard') go(state.view); else go(state.view); }
    else toast((res && res.error) || 'Opslaan mislukt', true);
  };
}

// Gezocht
VIEWS.wanted = async () => {
  let history = false;
  const draw = async () => {
    const rows = await api('wantedList', { history }) || [];
    $('#view').innerHTML = `
      <div class="row spread" style="margin-bottom:14px">
        <div class="row"><button class="btn ${history ? 'ghost' : ''}" id="tActive">Actief</button><button class="btn ${history ? '' : 'ghost'}" id="tHist">Historiek</button></div>
      </div>
      <div class="list">${rows.map((w) => `
        <div class="item">
          <div class="row spread">
            <div class="click" style="cursor:pointer" ${w.kind === 'citizen' ? `data-citizen="${esc(w.identifier)}"` : `data-plate="${esc(w.identifier)}"`}>
              <div class="t">${esc(w.label)} <span class="tag red">${w.kind === 'citizen' ? 'Persoon' : 'Voertuig'}</span></div>
              <div class="m">${esc(w.reason)}</div>
              <div class="m">${esc(w.officer_name)} &middot; ${fmtDate(w.created_at)}${w.resolved_by ? ' &middot; opgeheven door ' + esc(w.resolved_by) : ''}</div>
            </div>
            ${history ? '' : `<button class="btn small" data-resolve="${w.id}">Opheffen</button>`}
          </div>
        </div>`).join('') || '<div class="empty">Niets gevonden</div>'}</div>`;
    bindClicks($('#view'));
    $('#tActive').onclick = () => { history = false; draw(); };
    $('#tHist').onclick = () => { history = true; draw(); };
    $$('[data-resolve]').forEach((b) => b.onclick = async () => { await api('wantedResolve', { id: b.dataset.resolve }); toast('Opsporing opgeheven'); draw(); });
  };
  draw();
};

function openWantedModal(kind, identifier, label, done) {
  openModal(`
    <h2>${kind === 'citizen' ? 'Persoon' : 'Voertuig'} als gezocht melden</h2>
    <div style="color:var(--muted)">${esc(label)}</div>
    <label>Reden</label><textarea id="wReason" style="min-height:100px"></textarea>
    ${kind === 'citizen' ? '<label style="display:flex;gap:8px;align-items:center;margin-top:12px;color:var(--text)"><input type="checkbox" id="wVeh" style="width:auto" checked> Ook zijn/haar voertuigen als gezocht melden (nummerplaatscanner)</label>' : ''}
    <div class="row spread" style="margin-top:18px">
      <button class="btn ghost" id="wCancel">Annuleren</button><button class="btn danger" id="wSave">Melden</button>
    </div>`);
  $('#wCancel').onclick = closeModal;
  $('#wSave').onclick = async () => {
    const res = await api('wantedAdd', { kind, identifier, reason: $('#wReason').value, includeVehicles: !!($('#wVeh') && $('#wVeh').checked) });
    if (res && res.ok) { toast(res.vehicles ? `Opsporing aangemaakt (+${res.vehicles} voertuig(en))` : 'Opsporing aangemaakt'); closeModal(); done && done(); } else toast((res && res.error) || 'Mislukt', true);
  };
}

// Meldingen
VIEWS.dispatch = async () => {
  state.calls = await api('callsList') || [];
  drawCalls();
};

function updateBadge() {
  const b = $('#callBadge'), n = state.calls.length;
  b.textContent = n; b.classList.toggle('hidden', n === 0);
}

const CALL_STATUS_LABELS = { new: 'Nieuw', accepted: 'Aangenomen', enroute: 'Onderweg', onscene: 'Ter plaatse' };
function callStatusClass(value) { return ({ new: 'status-new', accepted: 'status-accepted', enroute: 'status-enroute', onscene: 'status-onscene' })[value] || 'status-new'; }
function priorityClass(value) { return `priority-${[1, 2, 3].includes(Number(value)) ? Number(value) : 2}`; }
function validCallCoords(call) {
  const x = Number(call.coords?.x), y = Number(call.coords?.y);
  return Number.isFinite(x) && Number.isFinite(y) && (x !== 0 || y !== 0) ? { x, y } : null;
}
function filteredDispatchCalls() {
  const q = String(state.callQuery || '').trim().toLocaleLowerCase('nl-BE');
  return state.calls.filter((c) => {
    const matchesQuery = !q || [c.title, c.code, c.street, c.message, c.caller, ...(c.units || []).map((u) => `${u.callsign} ${u.name}`)].some((v) => String(v || '').toLocaleLowerCase('nl-BE').includes(q));
    return matchesQuery && (!state.callStatusFilter || c.status === state.callStatusFilter)
      && (!state.callPriorityFilter || Number(c.priority || 2) === Number(state.callPriorityFilter))
      && (!state.callCodeFilter || c.code === state.callCodeFilter);
  }).sort((a, b) => (Number(a.priority) || 2) - (Number(b.priority) || 2) || Number(b.time || 0) - Number(a.time || 0));
}
function dispatchMapMarkup(rows) {
  const points = rows.map((call) => ({ call, coords: validCallCoords(call) })).filter((p) => p.coords);
  if (!points.length) return `<div class="dispatch-map-empty">${rows.length ? 'Voor deze meldingen zijn geen GPS-coördinaten beschikbaar.' : 'Geen meldingen met GPS-coördinaten in dit filter.'}<small>Voeg X- en Y-coördinaten toe bij het aanmaken van een melding.</small></div>`;
  const w = 1000, h = 390, left = 62, right = 34, top = 26, bottom = 48;
  const xs = points.map((p) => p.coords.x), ys = points.map((p) => p.coords.y);
  let minX = Math.min(...xs), maxX = Math.max(...xs), minY = Math.min(...ys), maxY = Math.max(...ys);
  let spanX = Math.max(maxX - minX, 1200), spanY = Math.max(maxY - minY, 1200);
  const centerX = (minX + maxX) / 2, centerY = (minY + maxY) / 2;
  minX = centerX - spanX * .6; maxX = centerX + spanX * .6;
  minY = centerY - spanY * .6; maxY = centerY + spanY * .6;
  const px = (x) => left + (x - minX) / (maxX - minX) * (w - left - right);
  const py = (y) => h - bottom - (y - minY) / (maxY - minY) * (h - top - bottom);
  const grid = Array.from({ length: 7 }, (_, i) => {
    const x = left + i * (w - left - right) / 6;
    const y = top + i * (h - top - bottom) / 6;
    return `<path d="M${x} ${top}V${h-bottom} M${left} ${y}H${w-right}"/>`;
  }).join('');
  const markers = points.map(({ call, coords }, i) => {
    const x = px(coords.x), y = py(coords.y), color = Number(call.priority) === 1 ? '#e5484d' : Number(call.priority) === 3 ? '#2a6ad6' : '#e4b92a';
    return `<g class="dispatch-map-marker ${priorityClass(call.priority)}" data-map-call="${esc(call.id)}" tabindex="0" role="button" aria-label="Open melding ${esc(call.title)}" transform="translate(${x} ${y})"><circle r="17" fill="${color}" opacity=".2"/><circle r="10" fill="${color}" stroke="#fff" stroke-width="2"/><text x="0" y="-22" text-anchor="middle">${esc(call.code || `#${i + 1}`)}</text><title>${esc(call.title)} · ${esc(call.street)}</title></g>`;
  }).join('');
  return `<svg class="dispatch-map-svg" viewBox="0 0 ${w} ${h}" role="img" aria-label="Meldingen op basis van GTA X- en Y-coördinaten"><rect width="${w}" height="${h}" rx="10" class="dispatch-map-ground"/><g class="dispatch-map-grid">${grid}</g>${markers}<text class="dispatch-map-axis" x="${left}" y="${h-12}">X ${Math.round(minX)}</text><text class="dispatch-map-axis" x="${w-right}" y="${h-12}" text-anchor="end">X ${Math.round(maxX)}</text><text class="dispatch-map-axis" x="${left}" y="${top+12}">Y ${Math.round(maxY)}</text><text class="dispatch-map-axis" x="${left}" y="${h-bottom+14}">Y ${Math.round(minY)}</text></svg><div class="dispatch-map-caption">Tactisch coördinatenoverzicht · GTA-wereldcoördinaten</div>`;
}

function drawCalls() {
  updateBadge();
  if (state.view !== 'dispatch') return;
  const rows = filteredDispatchCalls();
  const codes = [...new Set(state.calls.map((c) => c.code).filter(Boolean))].sort();
  $('#view').innerHTML = `<div class="box"><div class="row spread"><div><span class="eyebrow">MELDKAMER</span><h3>Actieve meldingen</h3><p class="m">Neem een melding aan en houd je status bij, zodat collega's je inzet kunnen volgen.</p></div><button class="btn" id="newCall">+ Nieuwe melding</button></div></div>
    <div class="box dispatch-filters"><input id="callSearch" aria-label="Zoek meldingen" placeholder="Zoek titel, locatie, omschrijving of agent…" value="${esc(state.callQuery)}"><select id="callStatusFilter" aria-label="Filter op meldingsstatus"><option value="">Alle statussen</option>${Object.entries(CALL_STATUS_LABELS).map(([key, label]) => `<option value="${key}" ${state.callStatusFilter === key ? 'selected' : ''}>${label}</option>`).join('')}</select><select id="callPriorityFilter" aria-label="Filter op urgentie"><option value="">Alle urgenties</option><option value="1" ${state.callPriorityFilter === '1' ? 'selected' : ''}>Prioriteit 1 · Hoog</option><option value="2" ${state.callPriorityFilter === '2' ? 'selected' : ''}>Prioriteit 2 · Normaal</option><option value="3" ${state.callPriorityFilter === '3' ? 'selected' : ''}>Prioriteit 3 · Laag</option></select><select id="callCodeFilter" aria-label="Filter op code"><option value="">Alle codes</option>${codes.map((code) => `<option value="${esc(code)}" ${state.callCodeFilter === code ? 'selected' : ''}>${esc(code)}</option>`).join('')}</select></div>
    <div class="box dispatch-map-panel"><div class="row spread"><div><span class="eyebrow">LOCATIEOVERZICHT</span><h3>GTA-coördinaten</h3></div><span class="tag">${rows.filter(validCallCoords).length} met GPS</span></div><div id="dispatchMap">${dispatchMapMarkup(rows)}</div></div>
    <div class="dispatch-results-label">${rows.length} van ${state.calls.length} meldingen</div>
    <div id="dispatchCallList" class="list">${rows.map((c) => `
    <div class="item" data-call-card="${esc(c.id)}">
      <div class="dispatch-call-head"><div><div class="t"><span class="tag red">${esc(c.code)}</span><span class="tag ${priorityClass(c.priority)}">P${Number(c.priority) || 2} · ${['Hoog','Normaal','Laag'][(Number(c.priority) || 2) - 1]}</span>${esc(c.title)}</div>
          <div class="m">${esc(c.street || 'Onbekende locatie')} &middot; ${ago(c.time)} &middot; melder: ${esc(c.caller)}</div>
          ${c.message ? `<div style="margin-top:6px">${esc(c.message)}</div>` : ''}
          <div class="dispatch-units">${c.units.length ? c.units.map((u) => `<span class="dispatch-unit"><b>${esc(u.callsign || '—')} ${esc(u.name)}</b><small>${CALL_STATUS_LABELS[u.status] || 'Aangenomen'}</small></span>`).join('') : '<span class="m">Nog geen agent heeft deze melding aangenomen</span>'}</div>
        </div><span class="tag call-status ${callStatusClass(c.status)}">${CALL_STATUS_LABELS[c.status] || 'Nieuw'}</span></div>
      <div class="dispatch-call-actions">
        ${c.mine ? `<label class="dispatch-response-label">Mijn status<select data-call-response="${esc(c.id)}"><option value="accepted" ${c.myStatus === 'accepted' ? 'selected' : ''}>Aangenomen</option><option value="enroute" ${c.myStatus === 'enroute' ? 'selected' : ''}>Onderweg</option><option value="onscene" ${c.myStatus === 'onscene' ? 'selected' : ''}>Ter plaatse</option></select></label><button class="btn ghost small" data-detach="${esc(c.id)}">Afmelden</button>` : `<button class="btn small" data-accept="${esc(c.id)}">Melding aannemen</button>`}
        <button class="btn ghost small" data-gps="${esc(c.id)}" ${!validCallCoords(c) ? 'disabled title="Geen GPS-coördinaten opgegeven"' : ''}>GPS</button>
        <button class="btn ghost small" data-close="${esc(c.id)}">Sluiten</button>
      </div>
    </div>`).join('') || '<div class="empty">Geen meldingen voor deze filters</div>'}</div>`;
  const search = $('#callSearch');
  search.oninput = () => { const pos = search.selectionStart; state.callQuery = search.value; drawCalls(); const next = $('#callSearch'); next.focus(); next.setSelectionRange(pos, pos); };
  $('#callStatusFilter').onchange = (e) => { state.callStatusFilter = e.target.value; drawCalls(); };
  $('#callPriorityFilter').onchange = (e) => { state.callPriorityFilter = e.target.value; drawCalls(); };
  $('#callCodeFilter').onchange = (e) => { state.callCodeFilter = e.target.value; drawCalls(); };
  $$('[data-map-call]').forEach((marker) => {
    marker.onclick = () => focusDispatchCall(marker.dataset.mapCall);
    marker.onkeydown = (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); focusDispatchCall(marker.dataset.mapCall); } };
  });
  const newCall = $('#newCall'); if (newCall) newCall.onclick = openCallModal;
  $$('[data-accept]').forEach((b) => b.onclick = async () => {
    const r = await api('callRespond', { id: b.dataset.accept, status: 'accepted' });
    if (r && r.ok) { const hasGps = r.coords && (Number(r.coords.x) || Number(r.coords.y)); if (hasGps) await api('callGps', { id: b.dataset.accept }); toast(hasGps ? 'Melding aangenomen; route ingesteld.' : 'Melding aangenomen.'); }
    else toast(r?.error || 'Melding aannemen is mislukt.', true);
    state.calls = await api('callsList') || []; drawCalls();
  });
  $$('[data-call-response]').forEach((s) => s.onchange = async () => {
    const r = await api('callRespond', { id: s.dataset.callResponse, status: s.value });
    if (!r || !r.ok) toast(r?.error || 'Status wijzigen is mislukt.', true);
    else toast(`Status bijgewerkt: ${CALL_STATUS_LABELS[s.value]}.`);
    state.calls = await api('callsList') || []; drawCalls();
  });
  $$('[data-detach]').forEach((b) => b.onclick = async () => {
    await api('callAttach', { id: b.dataset.detach });
    state.calls = await api('callsList') || []; drawCalls();
  });
  $$('[data-gps]').forEach((b) => b.onclick = () => {
    const c = state.calls.find((x) => String(x.id) === b.dataset.gps);
    if (c) api('callGps', { id: c.id }).then((g) => { if (g && g.ok) toast('Navigatiepunt gestuurd naar je spel'); });
  });
  $$('[data-close]').forEach((b) => b.onclick = async () => {
    await api('callClose', { id: b.dataset.close });
    state.calls = await api('callsList') || []; drawCalls();
  });
}

function openCallModal() {
  openModal(`<h2>Nieuwe melding</h2>
    <p class="m">De melding verschijnt meteen in de MDT en wordt naar agenten in dienst verzonden.</p>
    <label>Titel *</label><input id="callTitle" maxlength="80" placeholder="Bijv. Verkeersongeval">
    <div class="grid2"><div><label>Urgentie</label><select id="callPriority"><option value="1">1 · Hoog</option><option value="2" selected>2 · Normaal</option><option value="3">3 · Laag</option></select></div><div><label>Prioriteitcode *</label><select id="callCode"><option>10-00</option><option>10-13</option><option>10-31</option><option>10-50</option><option>10-90</option><option>Prioriteit 1</option><option>Prioriteit 2</option><option>Prioriteit 3</option></select></div></div>
    <label>Locatie *</label><input id="callStreet" maxlength="80" placeholder="Straat, wijk of herkenningspunt">
    <label class="current-position-option"><input id="callUsePosition" type="checkbox"><span><b>Gebruik mijn huidige FiveM-positie</b><small>Je personage moet online zijn. De locatiecoördinaten worden bij verzenden opgehaald.</small></span></label>
    <label>Omschrijving</label><textarea id="callMessage" maxlength="400" placeholder="Wat is er aan de hand? Zijn er bijzonderheden?" style="min-height:100px"></textarea>
    <details style="margin-top:10px"><summary>GPS-coördinaten (optioneel)</summary><p class="m">Vul X en Y in om navigatie naar de locatie mogelijk te maken.</p><div class="grid2"><div><label>X</label><input id="callX" type="number" step="any" placeholder="X"></div><div><label>Y</label><input id="callY" type="number" step="any" placeholder="Y"></div></div></details>
    <div class="row spread" style="margin-top:18px"><button class="btn ghost" id="callCancel">Annuleren</button><button class="btn" id="callSave">Melding versturen</button></div>`);
  $('#callCancel').onclick = closeModal;
  $('#callSave').onclick = async () => {
    const button = $('#callSave'); button.disabled = true; button.textContent = 'Bezig…';
    const r = await api('callCreate', { title: $('#callTitle').value.trim(), code: $('#callCode').value, priority: Number($('#callPriority').value), street: $('#callStreet').value.trim(), message: $('#callMessage').value.trim(), x: $('#callX').value, y: $('#callY').value, useMyPosition: $('#callUsePosition').checked });
    if (r && r.ok) {
      toast(`Melding #${r.id} aangemaakt`); closeModal();
      state.calls = await api('callsList') || [];
      if (state.view === 'dispatch') drawCalls(); else if (state.view === 'dashboard') go('dashboard');
    } else {
      toast((r && r.error) || 'Melding opslaan is mislukt. Controleer je verbinding en probeer opnieuw.', true);
      if ($('#callSave')) { $('#callSave').disabled = false; $('#callSave').textContent = 'Melding versturen'; }
    }
  };
}

// Agenten
const hrs = (s) => { s = Number(s || 0); return `${Math.floor(s / 3600)}u ${String(Math.floor((s % 3600) / 60)).padStart(2, '0')}m`; };
VIEWS.officers = async () => {
  const [rows, duty] = await Promise.all([api('officers'), api('dutyHours')]);
  $('#view').innerHTML = `<div class="box"><div class="row spread"><div><span class="eyebrow">RADIO</span><h3>Mijn status</h3><p class="m">Kies de status die andere agenten bij je zien. Uit dienst wordt geregeld met de dienstknop in FiveM.</p></div><span class="tag blue">Code ${esc(state.me?.statusCode ?? 0)}</span></div><div class="row"><select id="radioStatus" class="grow">${RADIO_STATUSES.filter(([code]) => ['0','1','2','3','4','5','6','9'].includes(code)).map(([code,label]) => `<option value="${code}" ${String(state.me?.statusCode ?? 0) === code ? 'selected' : ''}>${code} · ${esc(label)}</option>`).join('')}</select><button class="btn" id="radioStatusSave">Status opslaan</button></div></div>
    <div class="box"><div class="row spread"><h3>Radio-statuscodes</h3><span class="m">Referentie</span></div><div class="grid2">${RADIO_STATUSES.map(([code,label]) => `<div class="item"><span class="tag">${code}</span> ${esc(label)}${code === '8' ? '<div class="m">Wordt bepaald door je dienststatus in FiveM.</div>' : ''}</div>`).join('')}</div></div>
    <div class="grid2">
    <div class="box"><h3>In dienst (${(rows || []).length})</h3><div class="list">${(rows || []).map((o) => `
      <div class="item"><div class="row spread"><div class="t">${esc(o.name)} <span class="tag green">${esc(o.callsign)}</span></div><span class="tag">${esc(o.statusCode)} · ${esc(radioStatusName(o.statusCode))}</span></div>
      <div class="m">${esc(o.job)}${o.grade ? ' &middot; ' + esc(o.grade) : ''}</div></div>`).join('') || '<div class="empty">Niemand in dienst</div>'}</div></div>
    <div class="box"><h3>Diensturen</h3><div class="list">${(duty || []).map((d) => `
      <div class="item"><div class="row spread"><div class="t">${esc(d.name)}</div><div><span class="tag">7 dagen: ${hrs(d.week)}</span><span class="tag">totaal: ${hrs(d.total)}</span></div></div></div>`).join('') || '<div class="empty">Nog geen uren geregistreerd</div>'}</div></div>
  </div>`;
  $('#radioStatusSave').onclick = async () => {
    const result = await api('officerStatusSet', { statusCode: $('#radioStatus').value });
    if (result?.ok) { state.me.statusCode = result.statusCode; toast('Radiostatus bijgewerkt'); go('officers'); }
    else toast(result?.error || 'Radiostatus niet opgeslagen.', true);
  };
};

function renderMe() {
  const discord = state.discord || {};
  const discordName = discord.displayName || discord.nickname || discord.username || state.me?.name || 'Discord-account';
  const rank = discord.rank || state.me?.grade || state.me?.job || 'Rang niet gevonden';
  const photo = discord.avatar ? `<img class="me-avatar" src="${esc(discord.avatar)}" alt="Discord-profielfoto">` : `<span class="me-avatar fallback">${esc((discordName[0] || '?').toUpperCase())}</span>`;
  $('#me').innerHTML = `<div class="me-identity">${photo}<div class="me-labels"><b>${esc(discordName)}</b><span>${discord.username ? `@${esc(discord.username)}` : 'Discord-account'}</span></div></div><div class="me-rank">${esc(rank)}</div><div class="me-detail"><span>Discord servernaam / roepnummer</span><b>${esc(discord.nickname || 'Niet ingesteld')}</b></div>${state.me ? `<div class="me-detail"><span>In-game roepnummer</span><b>${esc(state.me.callsign || 'Niet ingesteld')}</b></div>` : ''}${discord.admin ? '<span class="me-admin">Beheerrechten</span>' : ''}`;
}

function applyProfile(profile) {
  state.profile = {
    displayName: String(profile.displayName || ''),
    callsign: String(profile.callsign || ''),
    avatar: String(profile.avatar || ''),
    accent: ['blue', 'teal', 'violet'].includes(profile.accent) ? profile.accent : 'blue',
    compact: Boolean(profile.compact),
  };
  document.documentElement.dataset.mdtAccent = state.profile.accent;
  document.body.classList.toggle('mdt-compact', state.profile.compact);
  const button = $('#profileButton');
  const avatar = $('#railAvatar');
  const name = state.discord?.displayName || state.discord?.username || state.profile.displayName || state.me?.name || 'Discord-profiel';
  if (button) { button.title = `${name} · Profielinstellingen`; button.setAttribute('aria-label', `Profielinstellingen voor ${name}`); }
  const avatarUrl = state.discord?.avatar || state.profile.avatar;
  if (avatar) avatar.innerHTML = avatarUrl
    ? `<img src="${esc(avatarUrl)}" alt="Discord-profielfoto">`
    : esc(name.trim().split(/\s+/).map((part) => part[0]).slice(0, 2).join('').toUpperCase() || '?');
}

async function avatarFromFile(file) {
  if (!file || !['image/png', 'image/jpeg', 'image/webp'].includes(file.type) || file.size > 5_000_000) {
    throw new Error('Kies een PNG-, JPG- of WebP-afbeelding van maximaal 5 MB.');
  }
  const objectUrl = URL.createObjectURL(file);
  try {
    const image = new Image();
    image.src = objectUrl;
    await new Promise((resolve, reject) => { image.onload = resolve; image.onerror = () => reject(new Error('Deze afbeelding kan niet worden geopend.')); });
    for (const size of [128, 96, 80]) {
      const canvas = document.createElement('canvas'); canvas.width = size; canvas.height = size;
      const ctx = canvas.getContext('2d');
      const scale = Math.max(size / image.naturalWidth, size / image.naturalHeight);
      const width = image.naturalWidth * scale, height = image.naturalHeight * scale;
      ctx.drawImage(image, (size - width) / 2, (size - height) / 2, width, height);
      for (const quality of [.78, .62, .48]) {
        const data = canvas.toDataURL('image/webp', quality);
        if (data.length <= 48_000 && /^data:image\/(webp|png|jpeg);base64,/.test(data)) return data;
      }
    }
    throw new Error('Deze afbeelding blijft te groot. Kies een eenvoudigere afbeelding.');
  } finally { URL.revokeObjectURL(objectUrl); }
}

function openProfileSettings() {
  const p = state.profile || { displayName: '', avatar: '', accent: 'blue', compact: false };
  let avatar = p.avatar;
  openModal(`<div class="profile-settings-head"><div><span class="eyebrow">MIJN MDT</span><h2>Profiel & uiterlijk</h2><p>Deze voorkeuren worden bewaard voor je personage en gebruikt op de website én in de tablet.</p></div><span class="settings-preview" id="settingsPreview"></span></div>
    <label for="profileName">Weergavenaam</label><input id="profileName" maxlength="40" placeholder="Gebruik je karakternaam">
    <label for="profileCallsign">Roepnummer</label><input id="profileCallsign" maxlength="16" placeholder="Bijvoorbeeld 1-Adam-01"><small>Vul je serverroepnummer in. Dit wordt getoond bij je profiel en meldingen.</small>
    <div class="settings-photo-row"><div><label for="avatarFile">Profielfoto</label><small>Op de website staat je echte Discord-foto. Deze eigen MDT-foto wordt in de tablet gebruikt als Discord daar niet gekoppeld is.</small></div><div class="row"><button class="btn ghost small" id="chooseAvatar">Foto kiezen</button><button class="btn ghost small" id="clearAvatar">Verwijderen</button><input id="avatarFile" type="file" accept="image/png,image/jpeg,image/webp" hidden></div></div>
    <div class="settings-options"><div><label for="profileAccent">Accentkleur</label><select id="profileAccent"><option value="blue">Politieblauw</option><option value="teal">Turquoise</option><option value="violet">Paars</option></select></div><label class="compact-option"><input id="profileCompact" type="checkbox"><span><b>Compacte weergave</b><small>Minder tussenruimte, meer informatie in beeld</small></span></label></div>
    <p class="settings-note">Je officiële karakternaam blijft gebruikt op rapporten en in het logboek.</p>
    <div class="row spread settings-actions"><button class="btn ghost" id="profileCancel">Annuleren</button><button class="btn" id="profileSave">Instellingen opslaan</button></div>`);
  $('#profileName').value = p.displayName;
  $('#profileCallsign').value = p.callsign || '';
  $('#profileAccent').value = p.accent;
  $('#profileCompact').checked = p.compact;
  const preview = $('#settingsPreview');
  const drawPreview = () => {
    preview.innerHTML = avatar ? `<img src="${esc(avatar)}" alt="Profielfoto">` : `<span>${esc((p.displayName || state.me?.name || '?').trim().split(/\s+/).map((part) => part[0]).slice(0, 2).join('').toUpperCase())}</span>`;
  };
  drawPreview();
  $('#chooseAvatar').onclick = () => $('#avatarFile').click();
  $('#avatarFile').onchange = async () => {
    const file = $('#avatarFile').files?.[0]; if (!file) return;
    try { avatar = await avatarFromFile(file); drawPreview(); }
    catch (error) { toast(error.message || 'Afbeelding laden is niet gelukt.', true); }
  };
  $('#clearAvatar').onclick = () => { avatar = ''; drawPreview(); };
  $('#profileCancel').onclick = closeModal;
  $('#profileSave').onclick = async () => {
    const save = $('#profileSave'); save.disabled = true; save.textContent = 'Opslaan…';
    const result = await api('profileSave', { displayName: $('#profileName').value, callsign: $('#profileCallsign').value, avatar, accent: $('#profileAccent').value, compact: $('#profileCompact').checked });
    if (result?.ok) {
      applyProfile(result.profile || {}); if (state.me) state.me.callsign = result.profile?.callsign || state.me.callsign; renderMe(); closeModal(); toast('Profielinstellingen opgeslagen.');
    } else {
      save.disabled = false; save.textContent = 'Instellingen opslaan';
      toast(result?.error || 'Instellingen opslaan is niet gelukt.', true);
    }
  };
}

// Strafwetboek ----------------------------------------------------------
const groupBy = (rows, key) => rows.reduce((m, r) => { (m[r[key]] = m[r[key]] || []).push(r); return m; }, {});
const MIRANDA_STATEMENT = 'Bij deze bent u aangehouden op het verdenken van [reden]. U bent niet tot antwoorden verplicht. Alles wat u zegt, kan en zal tegen u gebruikt worden in een eventuele rechtszaak. U hebt recht op een advocaat. Indien u zich zelf geen advocaat kunt bekostigen, zal onze staat er eentje toewijzen. U heeft recht op medische hulp indien u medische hulp wenst. U heeft recht op een tolk indien u de Nederlandse taal niet verstaat. Bent u in kennis gesteld met uw rechten?';
const RADIO_STATUSES = [
  ['0', 'In dienst'], ['1', 'In dienst en beschikbaar'], ['2', 'Interventie: onderweg'],
  ['3', 'Interventie: ter plaatse'], ['4', 'Interventie: niet beschikbaar'],
  ['5', 'Interventie: afgesloten'], ['6', 'Assistentie: medisch'], ['7', '/'],
  ['8', 'Uit dienst'], ['9', 'Achtervolging: crash gehad'],
];
const radioStatusName = (code) => RADIO_STATUSES.find(([value]) => value === String(code ?? 0))?.[1] || 'Onbekend';

VIEWS.charges = async () => {
  let mode = 'book';
  let selectedSheet = 'Strafwetboek';
  let book = { sheets: [] };
  let bookError = false;
  let favoritesOnly = false;
  const favorites = new Set();
  const savedFavorites = await api('chargeFavorites') || [];
  savedFavorites.forEach((item) => favorites.add(String(item.item_key)));
  const bookItemKey = (row, article, title) => {
    const source = `${article}|${title}|${JSON.stringify(row)}`;
    let hash = 2166136261;
    for (let i = 0; i < source.length; i++) hash = Math.imul(hash ^ source.charCodeAt(i), 16777619);
    return (hash >>> 0).toString(36);
  };
  const linkedArticles = new Map();
  try { const response = await fetch('/strafwetboek.json'); if (!response.ok) throw new Error('wetboek ontbreekt'); book = await response.json(); }
  catch { bookError = true; }
  const renderPenaltyList = async (filter) => {
    const rows = await api('chargeList') || [];
    const f = (filter || '').trim().toLowerCase();
    const shown = rows.filter((r) => !f || [r.label, r.category, r.description].some((v) => String(v || '').toLowerCase().includes(f)));
    const groups = groupBy(shown, 'category');
    $('#chargeList').innerHTML = Object.keys(groups).map((cat) => `
      <details class="box cat" open><summary><span>${esc(cat)}</span><span class="tag">${groups[cat].length}</span></summary><div class="list" style="margin-top:10px">${groups[cat].map((c) => `
        <div class="item"><div class="row spread"><div><div class="t">${esc(c.label)}</div>${c.description ? `<div class="m">${esc(c.description)}</div>` : ''}</div>
          <div class="row"><span class="tag">${money(c.fine)}</span><span class="tag">${esc(c.jail)} mnd cel</span>${Number(c.points) > 0 ? `<span class="tag yellow">${esc(c.points)} punten</span>` : ''}${state.canManage ? `<button class="btn ghost small" data-editcharge="${c.id}">Bewerk</button>` : ''}</div></div></div>`).join('')}</div></details>`).join('') || '<div class="empty">Nog geen eigen MDT-strafprofielen. Beheerders kunnen ze toevoegen.</div>';
    $$('[data-editcharge]').forEach((b) => b.onclick = () => openChargeEditor(rows.find((r) => String(r.id) === b.dataset.editcharge), () => go('charges')));
  };
  const renderBook = (filter) => {
    const f = (filter || '').trim().toLocaleLowerCase('nl').normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const sheets = book.sheets || [];
    const chosen = selectedSheet === '__all' ? sheets : sheets.filter((s) => s.name === selectedSheet);
    const entries = chosen.flatMap((sheet) => (sheet.rows || []).map((row) => ({ sheet: sheet.name, title: sheet.title, row })));
    const shown = entries.filter(({ row }) => {
      const haystack = Object.values(row).join(' ').toLocaleLowerCase('nl').normalize('NFD').replace(/[\u0300-\u036f]/g, '');
      const key = bookItemKey(row);
      return (!f || haystack.includes(f)) && (!favoritesOnly || favorites.has(key));
    });
    const pick = (row, names) => { const key = Object.keys(row).find((k) => names.includes(k)); return key ? row[key] : ''; };
    const titleKeys = ['Misdrijf', 'Feit', 'Situatie', 'Thema', 'Niveau', 'Basis', 'Artikel / basis', 'Artikel', 'Type', 'Domein'];
    const articleKeys = ['Artikel', 'Artikel / basis', 'Basis', 'Type', 'Niveau'];
    const descriptionKeys = ['Korte uitleg', 'Omschrijving', 'Hoofdstraf / mogelijke vrijheidsstraf', 'Hoofdstraf volgens niveau', 'Situatie', 'Uitleg'];
    $('#chargeCount').textContent = `${shown.length} van ${entries.length} onderdelen`;
    linkedArticles.clear();
    $('#chargeList').innerHTML = shown.map(({ sheet, row }) => {
      const titleKey = Object.keys(row).find((k) => titleKeys.includes(k) && row[k]);
      const title = titleKey ? row[titleKey] : Object.values(row).find(Boolean) || sheet;
      const article = pick(row, articleKeys);
      const descriptionKey = Object.keys(row).find((k) => descriptionKeys.includes(k) && row[k] && k !== titleKey);
      const description = descriptionKey ? row[descriptionKey] : '';
      const category = pick(row, ['Categorie', 'Domein', 'Thema', 'Onderwerp']);
      const source = pick(row, ['Bron URL']);
      const favoriteId = bookItemKey(row);
      linkedArticles.set(favoriteId, { sheet, row, category, title, article, description });
      const favoriteButton = `<button class="btn ghost small statute-favorite ${favorites.has(favoriteId) ? 'is-favorite' : ''}" data-favorite="${esc(favoriteId)}" aria-label="${favorites.has(favoriteId) ? 'Verwijder favoriet' : 'Bewaar als favoriet'}" aria-pressed="${favorites.has(favoriteId)}">${favorites.has(favoriteId) ? '★' : '☆'}</button>`;
      const linkButton = state.canManage ? `<button class="btn ghost small" data-link-article="${esc(favoriteId)}">Koppel aan MDT-strafprofiel</button>` : '';
      const hiddenKeys = new Set([titleKey, descriptionKey, 'Bron URL', 'Categorie', 'Domein', 'Thema', 'Onderwerp']);
      const facts = Object.entries(row).filter(([k, v]) => v && !hiddenKeys.has(k)).map(([k, v]) => `<div class="statute-fact"><span>${esc(k)}</span><b>${esc(v)}</b></div>`).join('');
      return `<article class="box statute-card"><div class="row spread statute-head"><div><div class="statute-kicker">${esc(sheet)}${category ? ` · ${esc(category)}` : ''}</div><h3>${esc(title)}</h3></div><div class="row">${article ? `<span class="tag statute-article">${esc(article)}</span>` : ''}${favoriteButton}</div></div>${description ? `<p class="statute-description">${esc(description)}</p>` : ''}${facts ? `<div class="statute-facts">${facts}</div>` : ''}<div class="statute-card-actions">${source.startsWith('https://') ? `<a class="statute-source" href="${esc(source)}" target="_blank" rel="noopener noreferrer">Bron bekijken ↗</a>` : '<span></span>'}${linkButton}</div></article>`;
    }).join('') || '<div class="empty">Geen resultaten. Probeer een ander zoekwoord of kies een ander onderdeel.</div>';
    $$('[data-favorite]').forEach((button) => button.onclick = async () => {
      const key = button.dataset.favorite;
      const enabled = !favorites.has(key);
      if (enabled) favorites.add(key); else favorites.delete(key);
      const result = await api('chargeFavoriteSet', { key, enabled });
      if (!result || !result.ok) {
        if (enabled) favorites.delete(key); else favorites.add(key);
        toast((result && result.error) || 'Favoriet niet opgeslagen. Probeer opnieuw.', true);
      }
      renderBook($('#chargeFilter').value);
    });
    $$('[data-link-article]').forEach((button) => button.onclick = () => {
      const item = linkedArticles.get(button.dataset.linkArticle);
      if (!item) return;
      const group = item.category || item.sheet || 'Wetboek';
      const label = [item.article, item.title].filter(Boolean).join(' · ').slice(0, 120);
      const desc = [item.description, pick(item.row, ['Praktijknotitie', 'Bijzonderheden / verzwarend', 'Graad / opmerkingen'])].filter(Boolean).join(' ').slice(0, 255);
      openChargeEditor({ category: group.slice(0, 40), label, description: desc, fine: 0, jail: 0, points: 0 }, () => go('charges'));
    });
  };
  $('#view').innerHTML = `<section class="statute-intro box"><div><div class="statute-kicker">FOCUS · JUSTITIE</div><h2>Strafwetboek & naslagwerk</h2><p>Doorzoek je aangeleverde wetboek, verkeersregels en aanvullende richtlijnen.</p></div><span class="tag">${book.sheets.reduce((n, s) => n + (s.rows || []).length, 0)} onderdelen</span></section>
    <div class="statute-toolbar"><div class="statute-tabs"><button class="btn" id="bookMode">Wetboek doorzoeken</button><button class="btn ghost" id="penaltyMode">MDT-strafprofielen</button><button class="btn ghost" id="rightsMode">Aanhoudingsrechten</button></div><select id="chargeSheet" aria-label="Onderdeel kiezen"><option value="__all">Alle onderdelen</option>${book.sheets.map((s) => `<option value="${esc(s.name)}" ${s.name === selectedSheet ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}</select><button class="btn ghost" id="favoriteMode" aria-pressed="false">☆ Favorieten</button><input id="chargeFilter" class="grow" placeholder="Zoek artikel, misdrijf, uitleg of bedrag…" autocomplete="off"></div>
    ${bookError ? '<div class="empty">Het strafwetboekbestand is niet geladen. Plaats strafwetboek.json in de public-map van de website.</div>' : ''}<div class="row spread statute-resultline"><span id="chargeCount"></span><span>Gebruik de bronlink voor de volledige tekst.</span></div><div id="chargeList" class="statute-list"></div>`;
  const input = $('#chargeFilter');
  const sheetSelect = $('#chargeSheet');
  const bookButton = $('#bookMode'); const penaltyButton = $('#penaltyMode'); const rightsButton = $('#rightsMode');
  const favoriteButton = $('#favoriteMode');
  const draw = () => {
    const inBook = mode === 'book', inPenalties = mode === 'penalties', inRights = mode === 'rights';
    sheetSelect.classList.toggle('hidden', !inBook);
    favoriteButton.classList.toggle('hidden', !inBook);
    input.classList.toggle('hidden', inRights);
    favoriteButton.classList.toggle('is-favorite', favoritesOnly);
    favoriteButton.setAttribute('aria-pressed', String(favoritesOnly));
    favoriteButton.textContent = favoritesOnly ? '★ Favorieten actief' : '☆ Favorieten';
    bookButton.classList.toggle('ghost', !inBook); penaltyButton.classList.toggle('ghost', !inPenalties); rightsButton.classList.toggle('ghost', !inRights);
    $('#chargeCount').classList.toggle('hidden', !inBook);
    $('#chargeCount').nextElementSibling.classList.toggle('hidden', !inBook);
    if (inBook) renderBook(input.value);
    else if (inPenalties) renderPenaltyList(input.value);
    else {
      $('#chargeCount').textContent = 'Aanhouding';
      $('#chargeList').innerHTML = `<article class="box statute-card"><div class="statute-kicker">FOCUS · AANHOUDING</div><h3>Rechtenverklaring (Miranda-tekst)</h3><p class="statute-description">Gebruik de tekst bij iedere aanhouding. Vul de verdenking in op de plaats van <b>[reden]</b>.</p><blockquote class="miranda-text">${esc(MIRANDA_STATEMENT)}</blockquote><div class="row"><button class="btn" id="copyMiranda">Tekst kopiëren</button><button class="btn ghost" id="copyMirandaReason">Kopieer met verdenking…</button></div></article>`;
      $('#copyMiranda').onclick = async () => { try { await navigator.clipboard.writeText(MIRANDA_STATEMENT); toast('Rechtenverklaring gekopieerd'); } catch { toast('Kopiëren wordt niet ondersteund in deze omgeving.', true); } };
      $('#copyMirandaReason').onclick = async () => {
        const reason = window.prompt('Welke verdenking wil je invullen?');
        if (reason === null) return;
        try { await navigator.clipboard.writeText(MIRANDA_STATEMENT.replace('[reden]', reason.trim() || '[reden]')); toast('Rechtenverklaring gekopieerd'); } catch { toast('Kopiëren wordt niet ondersteund in deze omgeving.', true); }
      };
    }
  };
  input.addEventListener('input', debounce(draw, 100));
  sheetSelect.addEventListener('change', () => { selectedSheet = sheetSelect.value; draw(); });
  bookButton.onclick = () => { mode = 'book'; input.placeholder = 'Zoek artikel, misdrijf, uitleg of bedrag…'; draw(); };
  penaltyButton.onclick = () => { mode = 'penalties'; input.placeholder = 'Zoek in eigen MDT-strafprofielen…'; draw(); };
  rightsButton.onclick = () => { mode = 'rights'; input.placeholder = 'Rechtenverklaring'; draw(); };
  favoriteButton.onclick = () => { favoritesOnly = !favoritesOnly; draw(); };
  draw();
  input.focus();
};

function openChargeEditor(c, done) {
  c = c || { category: '', label: '', fine: 0, jail: 0, points: 0, description: '' };
  openModal(`<h2>${c.id ? 'Misdrijf bewerken' : 'Nieuw misdrijf'}</h2>
    <label>Categorie</label><input id="cCat" maxlength="40" value="${esc(c.category)}" placeholder="Bv. Verkeer">
    <label>Omschrijving</label><input id="cLabel" maxlength="120" value="${esc(c.label)}">
    <div class="row"><div class="grow"><label>Boete (&euro;)</label><input id="cFine" type="number" min="0" value="${esc(c.fine)}"></div>
    <div class="grow"><label>Celstraf (maanden)</label><input id="cJail" type="number" min="0" value="${esc(c.jail)}"></div>
    <div class="grow"><label>Rijbewijspunten</label><input id="cPoints" type="number" min="0" value="${esc(c.points || 0)}"></div></div>
    <label>Toelichting (optioneel)</label><input id="cDesc" maxlength="255" value="${esc(c.description || '')}">
    <div class="row spread" style="margin-top:18px">
      <div class="row"><button class="btn ghost" id="cCancel">Annuleren</button>${c.id ? '<button class="btn danger" id="cDel">Verwijderen</button>' : ''}</div>
      <button class="btn" id="cSave">Opslaan</button></div>`);
  $('#cCancel').onclick = closeModal;
  const del = $('#cDel');
  if (del) del.onclick = async () => {
    if (!confirm('Dit misdrijf verwijderen? Bestaande strafbladen blijven behouden.')) return;
    const r = await api('chargeDelete', { id: c.id });
    if (r && r.ok) { closeModal(); done(); } else toast((r && r.error) || 'Mislukt', true);
  };
  $('#cSave').onclick = async () => {
    const r = await api('chargeSave', { id: c.id, category: $('#cCat').value, label: $('#cLabel').value, fine: $('#cFine').value, jail: $('#cJail').value, points: $('#cPoints').value, description: $('#cDesc').value });
    if (r && r.ok) { toast('Opgeslagen'); closeModal(); done(); } else toast((r && r.error) || 'Mislukt', true);
  };
}

async function openSentenceModal(citizen, done) {
  const rows = await api('chargeList') || [];
  const picked = new Set();
  const requestId = newRequestId();
  openModal(`<h2>Straf opleggen</h2><div style="color:var(--muted)">${esc(citizen.name)} &middot; ${esc(citizen.citizenid)}</div>
    <label>Zoek misdrijf</label><input id="sFilter" placeholder="Filter..." autocomplete="off">
    <div id="sList" style="max-height:260px;overflow-y:auto;margin-top:8px"></div>
    <div class="box" style="margin-top:10px"><div class="row spread"><div id="sTotal"></div></div></div>
    <div class="row"><div class="grow"><label>Notitie (optioneel)</label><input id="sNote" maxlength="500"></div>
    <div style="width:170px"><label>Rapportnr. (optioneel)</label><input id="sReport" type="number" min="1" placeholder="Bv. 12"></div></div>
    <div class="row spread" style="margin-top:18px"><button class="btn ghost" id="sCancel">Annuleren</button><button class="btn" id="sSave">Straf opleggen</button></div>`);

  const draw = () => {
    const f = $('#sFilter').value.trim().toLowerCase();
    const shown = rows.filter((r) => !f || r.label.toLowerCase().includes(f) || r.category.toLowerCase().includes(f));
    const groups = groupBy(shown, 'category');
    $('#sList').innerHTML = Object.keys(groups).map((cat) => `<div class="m" style="margin:8px 0 4px;color:var(--muted);font-size:12px">${esc(cat)}</div>` +
      groups[cat].map((c) => `<label style="display:flex;gap:10px;align-items:center;margin:0 0 4px;padding:7px 10px;background:var(--panel);border:1px solid var(--line);border-radius:8px;color:var(--text);cursor:pointer">
        <input type="checkbox" style="width:auto" data-charge="${c.id}" ${picked.has(c.id) ? 'checked' : ''}>
        <span class="grow">${esc(c.label)}</span><span class="tag">${money(c.fine)}</span><span class="tag">${esc(c.jail)} mnd</span>${Number(c.points) > 0 ? `<span class="tag yellow">${esc(c.points)} pt</span>` : ''}</label>`).join('')).join('') || '<div class="empty">Geen resultaten</div>';
    $$('[data-charge]').forEach((cb) => cb.onchange = () => { const id = Number(cb.dataset.charge); cb.checked ? picked.add(id) : picked.delete(id); total(); });
  };
  const total = () => {
    const sel = rows.filter((r) => picked.has(r.id));
    $('#sTotal').innerHTML = `Totaal: <b>${money(sel.reduce((s, r) => s + r.fine, 0))}</b> &middot; <b>${sel.reduce((s, r) => s + r.jail, 0)}</b> maanden cel &middot; <b>${sel.reduce((s, r) => s + Number(r.points || 0), 0)}</b> punten &middot; ${sel.length} misdrijf/misdrijven`;
  };
  $('#sFilter').addEventListener('input', draw);
  draw(); total();
  $('#sCancel').onclick = closeModal;
  $('#sSave').onclick = async () => {
    if (!picked.size) return toast('Kies minstens één misdrijf.', true);
    const btn = $('#sSave');
    btn.disabled = true; btn.textContent = 'Bezig met verwerken…';
    let r = await api('sentenceCreate', { citizenid: citizen.citizenid, charges: [...picked], note: $('#sNote').value, reportId: $('#sReport').value || undefined, requestId });
    if (!r || r.pending) {
      for (let i = 0; i < 10; i++) {
        await new Promise((resolve) => setTimeout(resolve, 500));
        const status = await api('sentenceStatus', { citizenid: citizen.citizenid, requestId });
        if (status && status.status === 'completed') { r = status.result; break; }
        if (status && status.status === 'missing') break;
      }
    }
    if (!btn.isConnected) { if (r && r.ok) toast(`Straf verwerkt (#${r.recordId}). Heropen het profiel om de status te zien.`); return; }
    if (!r || !r.ok) {
      btn.disabled = false; btn.textContent = 'Opnieuw controleren';
      return toast((r && r.error) || 'De status is nog niet bekend. Controleer het vonnislogboek voordat je een nieuwe straf aanmaakt.', true);
    }
    if (r.duplicate) { toast(`Deze straf was al verwerkt (#${r.recordId}).`); closeModal(); done(); return; }
    const parts = [];
    if (r.fine > 0) parts.push(r.invoiced ? `Factuur #${r.invoiceId} aangemaakt (${money(r.fine)})` : (r.warning || 'Boete niet gefactureerd'));
    const jailMsg = { jailed: 'burger is naar de gevangenis gestuurd', queued: 'burger is offline: celstraf start bij het inloggen',
      failed: 'gevangenis mislukt (agent in dienst en binnen 30 m?)', noresource: 'jail-script draait niet' }[r.jailStatus];
    if (r.jail > 0 && jailMsg) parts.push(jailMsg.charAt(0).toUpperCase() + jailMsg.slice(1));
    if (r.points > 0) parts.push(`${r.points} punten afgetrokken (nog ${r.pointsLeft})${r.licenceRevoked ? ', rijbewijs ingetrokken' : ''}`);
    if (!parts.length) parts.push('Straf opgelegd');
    const bad = (r.fine > 0 && !r.invoiced) || r.jailStatus === 'failed' || r.jailStatus === 'noresource';
    toast(parts.join(' · '), bad);
    closeModal(); done();
  };
}

// Zaken -----------------------------------------------------------------
VIEWS.cases = () => {
  let offset = 0, version = 0, allRows = [];
  const extra = `<select id="cStatus" style="width:170px"><option value="">Alle statussen</option>${state.caseStatuses.map((s) => `<option>${esc(s)}</option>`).join('')}</select><button class="btn" id="newCase">+ Nieuwe zaak</button>`;
  const q = searchBar('Zoek zaak (titel, nummer, agent, persoon, plaat)...', async (text) => {
    offset = 0; allRows = [];
    const current = ++version;
    const sel = $('#cStatus');
    const rows = await api('caseList', { query: text, status: sel ? sel.value : '', offset });
    if (state.view !== 'cases' || current !== version) return;
    if (!rows) { const target = $('#results'); if (target) target.innerHTML = '<div class="empty">Zaken laden is niet gelukt. Probeer opnieuw.</div>'; return; }
    allRows = rows;
    const res = $('#results');
    if (!res) return; // scherm is intussen gewisseld
    const draw = () => {
      res.innerHTML = allRows.map(caseRow).join('') || '<div class="empty">Geen zaken</div>';
      if (rows.length === 60 && allRows.length >= offset + rows.length) res.innerHTML += '<button class="btn ghost load-more" id="caseMore">Meer zaken laden</button>';
      bindClicks(res);
      const more = $('#caseMore', res);
      if (more) more.onclick = async () => {
        more.disabled = true; more.textContent = 'Laden…';
        const pageOffset = offset + 60, pageVersion = version;
        const next = await api('caseList', { query: q.value.trim(), status: $('#cStatus')?.value || '', offset: pageOffset });
        if (!next) { more.disabled = false; more.textContent = 'Opnieuw laden'; return; }
        if (state.view !== 'cases' || pageVersion !== version) return;
        offset = pageOffset; allRows = allRows.concat(next);
        draw();
      };
    };
    draw();
  }, extra);
  $('#view').insertAdjacentHTML('afterbegin', '<div class="section-intro"><span class="eyebrow">DOSSIERBEHEER</span><h2>Alle zaken op één plek</h2><p>Zoek dossiers op titel, zaaknummer, agent, betrokken persoon of kenteken. Open een dossier om gekoppelde rapporten en registraties te bekijken.</p></div>');
  $('#newCase').onclick = () => openCaseEditor(null);
  $('#cStatus').onchange = () => q.dispatchEvent(new Event('input'));
  q.dispatchEvent(new Event('input'));
};

async function openCase(id) {
  const c = await api('caseGet', { id });
  if (!c) return toast('Zaak niet gevonden', true);
  openModal(`
    <div class="row spread"><h2>#${esc(c.id)} &middot; ${esc(c.title)}</h2><span class="tag">${esc(c.status)}</span></div>
    <div style="color:var(--muted);font-size:12px;margin-bottom:12px">${esc(c.officer_name)} &middot; ${fmtDate(c.created_at)}${c.updated_at !== c.created_at ? ' (bijgewerkt ' + fmtDate(c.updated_at) + ')' : ''}</div>
    <div class="box"><pre class="desc">${esc(c.description || '-')}</pre></div>
    ${c.citizens.length ? `<h3 style="margin:14px 0 0;font-size:13px">Personen</h3><div class="chips">${c.citizens.map((p) => `<span class="chip" style="padding-right:10px;cursor:pointer" data-citizen="${esc(p.citizenid)}">${esc(p.name || p.citizenid)}</span>`).join('')}</div>` : ''}
    ${c.plates.length ? `<h3 style="margin:14px 0 0;font-size:13px">Voertuigen</h3><div class="chips">${c.plates.map((p) => `<span class="chip" style="padding-right:10px;cursor:pointer" data-plate="${esc(p)}">${esc(p)}</span>`).join('')}</div>` : ''}
    ${c.reports.length ? `<h3 style="margin:14px 0 6px;font-size:13px">Rapporten</h3><div class="list">${c.reports.map(reportRow).join('')}</div>` : ''}
    <div class="row spread" style="margin-top:18px">
      <div class="row"><button class="btn small" id="editCase">Bewerken</button>${state.canManage ? '<button class="btn danger small" id="delCase">Verwijderen</button>' : ''}</div>
      <button class="btn ghost small" id="closeM">Sluiten</button></div>`);
  $('#closeM').onclick = closeModal;
  $$('#modalCard [data-citizen]').forEach((el) => el.addEventListener('click', () => { closeModal(); go('citizens', el.dataset.citizen); }));
  $$('#modalCard [data-plate]').forEach((el) => el.addEventListener('click', () => { closeModal(); go('vehicles', el.dataset.plate); }));
  $$('#modalCard [data-report]').forEach((el) => el.addEventListener('click', () => openReport(el.dataset.report)));
  $('#editCase').onclick = () => openCaseEditor(c);
  const del = $('#delCase');
  if (del) del.onclick = async () => {
    if (!confirm('Deze zaak definitief verwijderen?')) return;
    const r = await api('caseDelete', { id: c.id });
    if (r && r.ok) { toast('Zaak verwijderd'); closeModal(); go('cases'); } else toast((r && r.error) || 'Mislukt', true);
  };
}

function openCaseEditor(existing) {
  const c = existing || { title: '', status: state.caseStatuses[0] || 'Open', description: '', citizens: [], plates: [], reportIds: [] };
  let citizens = [...c.citizens], plates = [...c.plates], reportIds = [...(c.reportIds || [])];
  openModal(`
    <h2>${existing ? 'Zaak #' + esc(c.id) + ' bewerken' : 'Nieuwe zaak'}</h2>
    ${existing ? '' : `<label>Sjabloon</label><select id="zTpl"><option value="">Geen sjabloon</option>${state.caseTemplates.map((t, i) => `<option value="${i}">${esc(t.label)}</option>`).join('')}</select>`}
    <label>Titel</label><input id="zTitle" maxlength="120" value="${esc(c.title)}">
    <label>Status</label><select id="zStatus">${state.caseStatuses.map((s) => `<option ${s === c.status ? 'selected' : ''}>${esc(s)}</option>`).join('')}</select>
    <label>Beschrijving</label><textarea id="zDesc">${esc(c.description)}</textarea>
    <label>Personen</label><input id="zPerson" placeholder="Zoek burger op naam of ID..." autocomplete="off">
    <div id="zSuggest" class="suggest hidden"></div><div id="zPeople" class="chips"></div>
    <label>Nummerplaten (Enter om toe te voegen)</label><input id="zPlate" placeholder="BV. ABC123" autocomplete="off"><div id="zPlates" class="chips"></div>
    <label>Gekoppelde rapporten (rapportnummer + Enter)</label><input id="zReport" type="number" min="1" placeholder="Bv. 12"><div id="zReports" class="chips"></div>
    <div class="row spread" style="margin-top:18px"><button class="btn ghost" id="zCancel">Annuleren</button><button class="btn" id="zSave">Opslaan</button></div>`);

  const chips = () => {
    $('#zPeople').innerHTML = citizens.map((p, i) => `<span class="chip">${esc(p.name || p.citizenid)}<button data-zp="${i}">&times;</button></span>`).join('');
    $('#zPlates').innerHTML = plates.map((p, i) => `<span class="chip">${esc(p)}<button data-zl="${i}">&times;</button></span>`).join('');
    $('#zReports').innerHTML = reportIds.map((p, i) => `<span class="chip">#${esc(p)}<button data-zr="${i}">&times;</button></span>`).join('');
    $$('[data-zp]').forEach((b) => b.onclick = () => { citizens.splice(+b.dataset.zp, 1); chips(); });
    $$('[data-zl]').forEach((b) => b.onclick = () => { plates.splice(+b.dataset.zl, 1); chips(); });
    $$('[data-zr]').forEach((b) => b.onclick = () => { reportIds.splice(+b.dataset.zr, 1); chips(); });
  };
  chips();

  const tpl = $('#zTpl');
  if (tpl) tpl.onchange = () => {
    const t = state.caseTemplates[tpl.value];
    if (!t) return;
    if (!$('#zTitle').value.trim()) $('#zTitle').value = t.title;
    if (!$('#zDesc').value.trim()) $('#zDesc').value = t.description;
  };
  $('#zPerson').addEventListener('input', debounce(async () => {
    const q = $('#zPerson').value.trim(), box = $('#zSuggest');
    if (q.length < 2) return box.classList.add('hidden');
    const rows = await api('citizenSearch', { query: q }) || [];
    box.innerHTML = rows.map((x) => `<div data-cid="${esc(x.citizenid)}" data-name="${esc(x.name)}">${esc(x.name)} <span style="color:var(--muted)">${esc(x.citizenid)}</span></div>`).join('') || '<div>Geen resultaten</div>';
    box.classList.remove('hidden');
    $$('[data-cid]', box).forEach((el) => el.onclick = () => {
      if (!citizens.some((p) => p.citizenid === el.dataset.cid)) citizens.push({ citizenid: el.dataset.cid, name: el.dataset.name });
      $('#zPerson').value = ''; box.classList.add('hidden'); chips();
    });
  }));
  $('#zPlate').addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    const v = e.target.value.trim().toUpperCase();
    if (v && !plates.includes(v)) plates.push(v);
    e.target.value = ''; chips();
  });
  $('#zReport').addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    const v = parseInt(e.target.value, 10);
    if (v && !reportIds.includes(v)) reportIds.push(v);
    e.target.value = ''; chips();
  });
  $('#zCancel').onclick = closeModal;
  $('#zSave').onclick = async () => {
    const pend = $('#zPlate').value.trim().toUpperCase();
    if (pend && !plates.includes(pend)) plates.push(pend);
    const r = await api('caseSave', { id: existing ? existing.id : undefined, title: $('#zTitle').value, status: $('#zStatus').value, description: $('#zDesc').value, citizens, plates, reports: reportIds });
    if (r && r.ok) { toast('Zaak opgeslagen'); closeModal(); if (state.view === 'cases') go('cases'); } else toast((r && r.error) || 'Opslaan mislukt', true);
  };
}


// Aanhoudingen, foto, vergunningen en punten -----------------------------
const yesNo = (v) => (v ? 'ja' : 'nee');

function arrestRow(a) {
  const d = a.data || {};
  return `<div class="item"><div class="row spread"><div class="t">${esc(d.reason || 'Aanhouding')}</div>
      <div>${d.rightsRead ? '<span class="tag green">rechten voorgelezen</span>' : '<span class="tag red">rechten niet voorgelezen</span>'}${d.force ? '<span class="tag yellow">geweld</span>' : ''}</div></div>
    <div class="m">${esc(d.location || '-')} &middot; advocaat: ${esc(d.lawyer || '-')} &middot; arts: ${yesNo(d.doctor)} &middot; ${esc(a.officer_name)} &middot; ${fmtDate(a.created_at)}
      ${a.report_id ? `<span class="tag" data-report="${esc(a.report_id)}" style="cursor:pointer;margin-left:6px">rapport #${esc(a.report_id)}</span>` : ''}
      ${state.canManage ? `<a href="#" data-delarrest="${a.id}" style="color:#ffb4b6;margin-left:8px">verwijder</a>` : ''}</div>
    ${d.injuries ? `<div class="m">Letsels: ${esc(d.injuries)}</div>` : ''}
    ${d.statement ? `<div class="m">Verklaring: ${esc(d.statement)}</div>` : ''}
    ${d.seized ? `<div class="m">In beslag genomen: ${esc(d.seized)}</div>` : ''}
    ${d.remarks ? `<div class="m">Opmerkingen: ${esc(d.remarks)}</div>` : ''}</div>`;
}

function openArrestModal(citizen, done) {
  openModal(`<h2>Aanhouding registreren</h2><div style="color:var(--muted)">${esc(citizen.name)} &middot; ${esc(citizen.citizenid)}</div>
    <label>Reden van aanhouding</label><input id="aReason" maxlength="200">
    <div class="row"><div class="grow"><label>Plaats</label><input id="aLoc" maxlength="120" placeholder="Bv. Korenmarkt"></div>
    <div style="width:170px"><label>Rapportnr. (optioneel)</label><input id="aReport" type="number" min="1"></div></div>
    <details style="margin-top:12px"><summary>Rechtenverklaring om voor te lezen</summary><div class="box miranda-text" style="margin-top:8px">${esc(MIRANDA_STATEMENT)}</div></details>
    <div class="row wrap" style="margin-top:12px;gap:18px">
      <label style="display:flex;gap:8px;align-items:center;margin:0;color:var(--text)"><input id="aRights" type="checkbox" style="width:auto"> Rechtenverklaring voorgelezen</label>
      <label style="display:flex;gap:8px;align-items:center;margin:0;color:var(--text)"><input id="aDoctor" type="checkbox" style="width:auto"> Arts opgeroepen</label>
      <label style="display:flex;gap:8px;align-items:center;margin:0;color:var(--text)"><input id="aForce" type="checkbox" style="width:auto"> Geweld toegepast</label>
    </div>
    <label>Advocaat</label><select id="aLawyer"><option value="niet gevraagd">Niet gevraagd</option><option value="gevraagd">Gevraagd</option><option value="aanwezig">Aanwezig</option></select>
    <label>Letsels (optioneel)</label><input id="aInj" maxlength="300">
    <label>Verklaring van de verdachte (optioneel)</label><textarea id="aStat" maxlength="1000" style="min-height:90px"></textarea>
    <label>In beslag genomen (optioneel)</label><input id="aSeized" maxlength="500">
    <label>Opmerkingen (optioneel)</label><input id="aRem" maxlength="500">
    <div class="row spread" style="margin-top:18px"><button class="btn ghost" id="aCancel">Annuleren</button><button class="btn" id="aSave">Aanhouding opslaan</button></div>`);
  $('#aCancel').onclick = closeModal;
  $('#aSave').onclick = async () => {
    const r = await api('arrestSave', {
      citizenid: citizen.citizenid, reason: $('#aReason').value, location: $('#aLoc').value, reportId: $('#aReport').value || undefined,
      rightsRead: $('#aRights').checked, doctor: $('#aDoctor').checked, force: $('#aForce').checked, lawyer: $('#aLawyer').value,
      injuries: $('#aInj').value, statement: $('#aStat').value, seized: $('#aSeized').value, remarks: $('#aRem').value,
    });
    if (r && r.ok) { toast('Aanhouding opgeslagen'); closeModal(); done(); } else toast((r && r.error) || 'Opslaan mislukt', true);
  };
}

function openPhotoModal(citizen, done) {
  openModal(`<h2>Foto van ${esc(citizen.name)}</h2>
    <label>Link naar de afbeelding (https)</label><input id="pUrl" maxlength="400" value="${esc(citizen.mugshot || '')}" placeholder="https://...">
    <div style="color:var(--muted);font-size:12px;margin-top:6px">Laat het veld leeg om de foto te verwijderen.</div>
    <div class="row spread" style="margin-top:18px"><button class="btn ghost" id="pCancel">Annuleren</button><button class="btn" id="pSave">Opslaan</button></div>`);
  $('#pCancel').onclick = closeModal;
  $('#pSave').onclick = async () => {
    const r = await api('photoSet', { citizenid: citizen.citizenid, url: $('#pUrl').value });
    if (r && r.ok) { toast('Foto opgeslagen'); closeModal(); done(); } else toast((r && r.error) || 'Opslaan mislukt', true);
  };
}

function openLicenceModal(citizen, key, grant, done) {
  const t = citizen.licenceTypes.find((x) => x.key === key);
  const label = t ? t.label : key;
  openModal(`<h2>${esc(label)} ${grant ? 'toekennen' : 'intrekken'}</h2><div style="color:var(--muted)">${esc(citizen.name)}</div>
    ${grant ? '' : '<label>Reden (verplicht)</label><input id="lReason" maxlength="200">'}
    <div class="row spread" style="margin-top:18px"><button class="btn ghost" id="lCancel">Annuleren</button><button class="btn ${grant ? 'ok' : 'danger'}" id="lSave">${grant ? 'Toekennen' : 'Intrekken'}</button></div>`);
  $('#lCancel').onclick = closeModal;
  $('#lSave').onclick = async () => {
    const r = await api('licenceSet', { citizenid: citizen.citizenid, key, value: grant, reason: grant ? '' : $('#lReason').value });
    if (r && r.ok) { toast(grant ? 'Vergunning toegekend' : 'Vergunning ingetrokken'); closeModal(); done(); } else toast((r && r.error) || 'Mislukt', true);
  };
}

function openPointsModal(citizen, done) {
  const max = citizen.maxPoints || 12;
  openModal(`<h2>Rijbewijspunten aanpassen</h2><div style="color:var(--muted)">${esc(citizen.name)}</div>
    <label>Aantal punten (0 tot ${max})</label><input id="ptVal" type="number" min="0" max="${max}" value="${esc(citizen.points)}">
    <div class="row spread" style="margin-top:18px"><button class="btn ghost" id="ptCancel">Annuleren</button><button class="btn" id="ptSave">Opslaan</button></div>`);
  $('#ptCancel').onclick = closeModal;
  $('#ptSave').onclick = async () => {
    const r = await api('pointsSet', { citizenid: citizen.citizenid, points: $('#ptVal').value });
    if (r && r.ok) { toast('Punten aangepast'); closeModal(); done(); } else toast((r && r.error) || 'Mislukt', true);
  };
}

// Vonnissen (justitie) ----------------------------------------------------
VIEWS.sentences = () => {
  let offset = 0, allRows = [];
  const extra = `<select id="rStatus" style="width:190px"><option value="actief">Te beoordelen</option><option value="bevestigd">Bevestigd</option><option value="verlaagd">Verlaagd</option><option value="ingetrokken">Ingetrokken</option><option value="alle">Alle</option></select>`;
  const q = searchBar('Zoek op naam, burger-ID of vonnisnummer...', async (text, isCurrent) => {
    offset = 0; allRows = [];
    const sel = $('#rStatus');
    const res = $('#results'); if (!res) return;
    res.innerHTML = '<div class="empty">Vonnissen zoeken...</div>';
    const rows = await api('recordList', { query: text, status: sel ? sel.value : 'actief', offset });
    if (!isCurrent()) return;
    if (!rows) { res.innerHTML = '<div class="empty">Vonnissen laden is niet gelukt. Probeer opnieuw.</div>'; return; }
    const currentRes = $('#results'); if (!currentRes) return;
    allRows = rows;
    const draw = () => {
    currentRes.innerHTML = allRows.map((r) => `
      <div class="item click" data-rec="${r.id}">
        <div class="row spread"><div class="t">#${esc(r.id)} &middot; ${esc(r.name || r.citizenid)}</div><span class="tag ${STATUS_CLASS[r.status] || ''}">${esc(r.status)}</span></div>
        <div class="m">${r.charges.map((c) => esc(c.label)).join(', ') || 'Onbekend'}</div>
        <div class="m">${money(r.fine)} &middot; ${esc(r.jail)} mnd cel &middot; ${esc(r.officer_name)} &middot; ${fmtDate(r.created_at)}</div></div>`).join('') || '<div class="empty">Geen vonnissen gevonden</div>';
    if (rows.length === 60 && allRows.length >= offset + rows.length) currentRes.innerHTML += '<button class="btn ghost load-more" id="recordMore">Meer vonnissen laden</button>';
    $$('[data-rec]', currentRes).forEach((el) => {
      el.tabIndex = 0; el.setAttribute('role', 'button');
      el.addEventListener('click', () => openReviewModal(allRows.find((x) => String(x.id) === el.dataset.rec), () => q.dispatchEvent(new Event('input'))));
      el.addEventListener('keydown', (event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); el.click(); } });
    });
    const more = $('#recordMore', currentRes);
    if (more) more.onclick = async () => {
      more.disabled = true; more.textContent = 'Laden…';
      const pageOffset = offset + 60;
      const next = await api('recordList', { query: q.value.trim(), status: $('#rStatus')?.value || 'actief', offset: pageOffset });
      if (!isCurrent()) return;
      if (!next) { more.disabled = false; more.textContent = 'Opnieuw laden'; return; }
      offset = pageOffset; allRows = allRows.concat(next); draw();
    };
    };
    draw();
  }, extra);
  $('#rStatus').onchange = () => q.dispatchEvent(new Event('input'));
  q.dispatchEvent(new Event('input'));
};

function openReviewModal(r, done) {
  if (!r) return;
  openModal(`<div class="row spread"><h2>Vonnis #${esc(r.id)}</h2><span class="tag ${STATUS_CLASS[r.status] || ''}">${esc(r.status)}</span></div>
    <div style="color:var(--muted);margin-bottom:10px">${esc(r.name || r.citizenid)} &middot; ${esc(r.officer_name)} &middot; ${fmtDate(r.created_at)}</div>
    <div class="box"><div class="t">${r.charges.map((c) => esc(c.label)).join(', ') || 'Onbekend'}</div>
      <div class="m">Boete ${r.original_fine != null && Number(r.original_fine) !== Number(r.fine) ? `<s>${money(r.original_fine)}</s> ` : ''}${money(r.fine)} &middot; ${esc(r.jail)} mnd cel${Number(r.points) > 0 ? ` &middot; ${esc(r.points)} punten` : ''}
      ${r.fine > 0 ? (r.invoiced ? '<span class="tag green">gefactureerd</span>' : '<span class="tag red">niet gefactureerd</span>') : ''}</div>
      ${r.note ? `<div class="m">${esc(r.note)}</div>` : ''}
      ${r.reviewed_by ? `<div class="m">Beoordeeld door ${esc(r.reviewed_by)}${r.review_note ? ': ' + esc(r.review_note) : ''}</div>` : ''}</div>
    <label>Nieuw boetebedrag (enkel bij verlagen)</label><input id="vFine" type="number" min="0" max="${Math.max(0, r.fine - 1)}" value="${Math.floor(r.fine / 2)}">
    <label>Motivering (verplicht bij verlagen en intrekken)</label><textarea id="vNote" maxlength="500" style="min-height:80px"></textarea>
    <div class="row spread" style="margin-top:18px"><button class="btn ghost" id="vClose">Sluiten</button>
      <div class="row"><button class="btn danger" id="vWithdraw">Intrekken</button><button class="btn" id="vReduce">Boete verlagen</button><button class="btn ok" id="vConfirm">Bevestigen</button></div></div>`);
  $('#vClose').onclick = closeModal;
  const send = async (action) => {
    const res = await api('recordReview', { id: r.id, action, fine: $('#vFine').value, note: $('#vNote').value });
    if (!res || !res.ok) return toast((res && res.error) || 'Mislukt', true);
    toast(res.warning || `Vonnis ${res.status}`, !!res.warning);
    closeModal(); done();
  };
  $('#vConfirm').onclick = () => send('confirm');
  $('#vReduce').onclick = () => send('reduce');
  $('#vWithdraw').onclick = () => { if (confirm('Dit vonnis intrekken? Een openstaande factuur wordt verwijderd.')) send('withdraw'); };
}

VIEWS.audit = async () => {
  const [rows, pending] = await Promise.all([api('auditList', { offset: 0 }), api('sentencePendingList')]);
  if (state.view !== 'audit') return;
  if (!rows) return $('#view').innerHTML = '<div class="empty">Het logboek kon niet worden geladen.</div>';
  let allRows = rows, offset = 0, pageSize = rows.length, generation = 0, timer;
  const labels = {
    sentenceCreate: 'Straf opgelegd', recordReview: 'Vonnis beoordeeld', recordDelete: 'Strafblad aangepast',
    reportSave: 'Rapport opgeslagen', reportDelete: 'Rapport verwijderd', caseSave: 'Zaak opgeslagen',
    caseDelete: 'Zaak verwijderd', wantedAdd: 'Opsporing aangemaakt', wantedResolve: 'Opsporing opgeheven',
    noteAdd: 'Notitie toegevoegd', noteDelete: 'Notitie verwijderd', arrestSave: 'Aanhouding opgeslagen',
    arrestDelete: 'Aanhouding verwijderd', licenceSet: 'Vergunning gewijzigd', pointsSet: 'Rijbewijspunten gewijzigd',
    photoSet: 'Profielfoto gewijzigd', chargeSave: 'Strafwetboek aangepast', chargeDelete: 'Misdrijf verwijderd',
    announcementAdd: 'Mededeling geplaatst', announcementDelete: 'Mededeling verwijderd', callAttach: 'Eenheid gekoppeld aan melding', callRespond: 'Meldingsstatus bijgewerkt', callClose: 'Melding gesloten',
  };
  $('#view').innerHTML = `<div class="box audit-intro"><div class="eyebrow">BEHEER & CONTROLE</div><h3>Recente wijzigingen</h3><p>Doorzoek de wijzigingsgeschiedenis. Per keer worden maximaal 50 acties geladen.</p></div>
    ${(pending || []).length ? `<div class="box audit-pending"><div class="row spread"><h3>Strafverzoeken ter controle</h3><span class="tag yellow">${pending.length}</span></div><p>Een onderbroken verwerking kan een factuur of strafblad achterlaten. Controleer deze aanvragen handmatig voordat je opnieuw handelt.</p><div class="list">${pending.map((r) => `<div class="item"><div class="row spread"><div class="t">Burger ${esc(r.citizenid)}</div><span class="tag yellow">controle vereist</span></div><div class="m">Aanvraag ${esc(r.request_id)} · agent ${esc(r.officer_cid)} · ${fmtDate(r.created_at)}</div></div>`).join('')}</div></div>` : ''}
    <div class="row" style="margin:0 0 12px"><input id="auditQ" class="grow" aria-label="Zoek in logboek" placeholder="Zoek agent, actie of dossiernummer..." autocomplete="off"></div>
    <div id="auditRows" class="list"></div><button id="auditMore" class="btn ghost load-more hidden">Meer acties laden</button>`;
  const list = $('#auditRows'), more = $('#auditMore'), input = $('#auditQ');
  const draw = () => {
    list.innerHTML = allRows.map((r) => {
      const detail = Object.entries(r.details || {}).filter(([, value]) => value !== null && value !== undefined && value !== '').map(([key, value]) => `${key}: ${value}`).join(' · ');
      return `<div class="item"><div class="row spread"><div class="t">${esc(labels[r.action] || r.action)} <span class="tag">${esc(r.entity)} ${esc(r.entity_id || '')}</span></div><span class="m">${fmtDate(r.created_at)}</span></div>
        <div class="m">${esc(r.actor_name)} · ${esc(r.actor_job)} · ID ${esc(r.actor_cid)}</div>${detail ? `<div class="audit-detail">${esc(detail)}</div>` : ''}</div>`;
    }).join('') || '<div class="empty">Geen acties gevonden.</div>';
    more.classList.toggle('hidden', pageSize < 50 || allRows.length < offset + 50);
  };
  draw();
  input.addEventListener('input', () => {
    const current = ++generation;
    more.classList.add('hidden');
    clearTimeout(timer);
    timer = setTimeout(async () => {
      if (state.view !== 'audit' || current !== generation) return;
      const q = input.value.trim();
      const next = await api('auditList', { query: q, offset: 0 });
      if (!next || state.view !== 'audit' || current !== generation) return;
      offset = 0; allRows = next; pageSize = next.length; draw();
    }, 300);
  });
  more.onclick = async () => {
    const current = generation, q = input.value.trim(), nextOffset = offset + 50;
    more.disabled = true; more.textContent = 'Laden…';
    const next = await api('auditList', { query: q, offset: nextOffset });
    more.disabled = false; more.textContent = 'Meer acties laden';
    if (!next || state.view !== 'audit' || current !== generation) return;
    offset = nextOffset; allRows = allRows.concat(next); pageSize = next.length; draw();
  };
};

// --- start ---------------------------------------------------------------
let knownCalls = new Set();
let callsPolling = false;
let currentDataRevision = null, revisionPolling = false;
async function pollDataRevision() {
  if (revisionPolling || document.hidden || sessionGone) return;
  revisionPolling = true;
  try {
    const data = await api('dataRevision');
    const revision = data && data.revision;
    if (typeof revision !== 'string') return;
    if (currentDataRevision === null) { currentDataRevision = revision; return; }
    if (revision !== currentDataRevision) {
      currentDataRevision = revision;
      refreshCurrentView();
      if (!deferredDataRefresh) toast('MDT bijgewerkt met de nieuwste gegevens.');
    }
  } finally { revisionPolling = false; }
}
async function pollCalls(first) {
  if (callsPolling || document.hidden) return;
  callsPolling = true;
  try {
  const rows = await api('callsList');
  if (!rows) return;
  if (!first) rows.filter((c) => !knownCalls.has(c.id)).forEach((c) => toast(`Nieuwe melding: ${c.code} ${c.title}`));
  knownCalls = new Set(rows.map((c) => c.id));
  state.calls = rows;
  if (state.view === 'dispatch') drawCalls(); else updateBadge();
  } finally { callsPolling = false; }
}
async function init() {
  const me = await fetch('/api/me').then((r) => r.json()).catch(() => ({ loggedIn: false }));
  if (!me.loggedIn) return showScreen('login');
  state.discord = me.discord || null;
  applyProfile({});
  renderMe();
  $('#app').classList.remove('hidden');
  go('dashboard');
  const revision = await api('dataRevision');
  currentDataRevision = revision && revision.revision || null;
  await pollCalls(true);
  setInterval(() => { if (!sessionGone && !document.hidden) { pollCalls(false); pollDataRevision(); } }, 5000);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && !sessionGone) { pollCalls(false); pollDataRevision(); }
  });
}
init();


