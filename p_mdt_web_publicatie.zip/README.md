# p_mdt_web - de politie-MDT als website

De website toont dezelfde MDT-gegevens als de tablet in FiveM. De resource `p_mdt` (versie 2.3) blijft draaien op je server: die voert acties uit en gebruikt dezelfde database voor beide schermen.

```
Browser  ->  p_mdt_web (deze map, op je VPS)  ->  FiveM-server (resource p_mdt)  ->  database, qbx_facturen, jail
```

## Zo werkt het
- De agent logt in met **Discord**. De website controleert eerst dat de gebruiker lid is van de ingestelde Discord-server en minstens één ingestelde politie-rol heeft. De rolcontrole wordt tijdens het gebruik opnieuw uitgevoerd.
- Het profiel toont de Discordnaam, de servernaam (gebruik die als roepnummer) en de hoogste politierang. Rangen boven Aspirant-commissaris krijgen op de website MDT-beheerrechten via `DISCORD_ADMIN_ROLE_IDS`; de algemene rol `Politie` geeft nooit beheerrechten.
- Het onderdeel **Strafwetboek** toont en doorzoekt de aangeleverde Excel-naslag in 15 onderdelen. De beheerbare MDT-strafprofielen blijven apart beschikbaar voor het opleggen van straffen.
- Wetboekfavorieten worden in de gedeelde MDT-database bewaard en zijn beschikbaar op de website en FiveM-tablet. Beheerders kunnen een wetboekitem vanuit de bron als vooringevuld MDT-strafprofiel openen.
- Vanuit Overzicht kun je snel een melding of rapport starten. In Meldingen kun je zelf een melding aanmaken; agenten in dienst krijgen die meteen in hun MDT. GPS-coördinaten zijn optioneel. Beheerders kunnen daarnaast teammededelingen plaatsen.
- Onder Agenten staan de opgegeven radiostatuscodes. Agenten kunnen hun status daar instellen; de lijst In dienst en het Overzicht tonen de actuele MDT-status. Code 8 (Uit dienst) blijft gekoppeld aan de dienststatus van FiveM.
- De aangeleverde Miranda-rechtenverklaring staat in het Strafwetboek en bij het formulier Aanhouding registreren. De tekst kan vanuit Strafwetboek worden gekopieerd.
- Als Discord de rollen weigert, vraagt `/auth/login?reauthorize=1` opnieuw toestemming voor `guilds.members.read`; de serverlog vermeldt de HTTP-status zonder toegangstokens te loggen.
- De resource zoekt het **online personage** met dat Discord-ID, controleert job, graad en dienst, en voert dan dezelfde acties uit als vroeger de tablet.
- Dus: **je personage moet in het spel online en in dienst zijn** om de MDT te gebruiken. Staat het spel uit, dan toont de website "Je personage is niet online".
- De website kan zelf niets in de database doen. Alle regels (grades, justitie, boetes) blijven in `p_mdt`.
- Het Logboek is zichtbaar voor beheerders met de ingestelde `Config.ManageGrade`. Je kunt daarin acties doorzoeken en per pagina 50 regels laden.
- De website controleert iedere 5 seconden op nieuwe MDT-wijzigingen. Als er iets verandert, wordt het geopende overzicht automatisch bijgewerkt; open formulieren blijven behouden.
- Als een strafaanvraag wordt onderbroken, controleert de MDT dezelfde aanvraag op status en voorkomt hij een dubbele verwerking. Eventuele afgebroken aanvragen staan in het Logboek voor handmatige controle.
- De verbindingsindicator bovenaan laat zien of de MDT-server reageert. `/healthz` is beschikbaar voor een eenvoudige controle van de website-service.

## Installeren (VPS met Node.js 18 of nieuwer)
1. Zet de map `p_mdt_web` op je VPS. Er zijn geen pakketten om te installeren.
2. **Discord:** ga naar https://discord.com/developers/applications, open de bestaande OAuth-app, en voeg onder OAuth2 als redirect toe: `https://mdt.jouwdomein.be/auth/callback`.
3. Zet in Discord bij **Gebruikersinstellingen > Geavanceerd** de **Ontwikkelaarsmodus** aan. Kopieer met rechtsklik de server-ID en de ID van elke politierol die toegang mag krijgen. Vul `DISCORD_GUILD_ID` in en zet alle toegestane politie-rol-ID's komma-gescheiden in `DISCORD_ALLOWED_ROLE_IDS`. Neem alle rangen op die op de politierollenlijst staan; laat `AFGEMELD` en andere niet-politierollen weg. Rolnamen zijn niet genoeg: de controle gebruikt de vaste Discord-rol-ID's.
4. Kopieer `.env.example` naar `.env` en vul alle waarden in. Agenten moeten bij de eerste aanmelding opnieuw toestemming geven voor het lezen van hun serverlidmaatschap. `FIVEM_SECRET` is een lange willekeurige tekst. Zet exact dezelfde tekst in `p_mdt/config.lua` bij `Config.Web.Secret`.
5. Start: `node server.js` (of `npm start`). De roltoegang blijft gesloten zolang de server-ID of de rol-ID-lijst ontbreekt.
6. Zet er HTTPS voor. Voorbeeld met Caddy (`/etc/caddy/Caddyfile`):
   ```
   mdt.jouwdomein.be {
       reverse_proxy 127.0.0.1:3000
   }
   ```
7. Laat het draaien als service. Voorbeeld `/etc/systemd/system/p_mdt_web.service`:
   ```
   [Unit]
   Description=p_mdt_web
   After=network.target

   [Service]
   WorkingDirectory=/opt/p_mdt_web
   ExecStart=/usr/bin/node server.js
   Restart=always
   User=mdt

   [Install]
   WantedBy=multi-user.target
   ```
   Daarna: `systemctl enable --now p_mdt_web`.

## Gratis online zetten (Render)
Render kan deze Node-website een publieke `onrender.com`-link en HTTPS geven. De gratis webservice slaapt na 15 minuten zonder bezoek en het eerste openen kan ongeveer een minuut duren. Dit is geschikt om gratis uit te proberen; voor een MDT die altijd direct beschikbaar moet zijn, is een betaalde host betrouwbaarder.

1. Zet alleen de map `p_mdt_web` in een GitHub-repository. Voeg `.env` nooit toe; geheimen horen in de instellingen van Render.
2. Kies in Render **New > Web Service**, koppel de repository, en stel de Root Directory in op `p_mdt_web` (laat leeg als deze map zelf de repository is). Gebruik `npm install` als Build Command en `npm start` als Start Command.
3. Na het aanmaken krijg je een publieke URL, bijvoorbeeld `https://jouw-mdt.onrender.com`. Vul die bij `PUBLIC_URL` in en voeg in Discord OAuth2 Redirects exact `https://jouw-mdt.onrender.com/auth/callback` toe.
4. Voeg in Render bij **Environment** de waarden toe voor `PUBLIC_URL`, `DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET`, `FIVEM_URL`, `FIVEM_SECRET` en `SESSION_SECRET`. Render levert zelf `PORT`; `HOST` staat standaard op `0.0.0.0`.
5. De FiveM-server moet bereikbaar zijn vanaf Render op `FIVEM_URL`. Gebruik daar het publieke adres van je game-server, niet `127.0.0.1`. Laat de API-poort alleen toe zoals nodig en houd `FIVEM_SECRET` geheim. Als je server alleen lokale verbindingen accepteert, kan Render er niet bij en is hosting op dezelfde VPS als FiveM de beste keuze.

## Back-up en herstel
De website bewaart geen eigen MDT-database: rapporten, dossiers, meldingen en strafgegevens staan in de MySQL-database die FiveM gebruikt. Stel daarom dagelijkse databaseback-ups in via je databasehost of hostingpaneel, bewaar ten minste één kopie buiten de server en probeer herstel eerst op een testdatabase. Bewaar `.env`, Discord-geheimen en `Config.Web.Secret` apart en veilig; stop die nooit in een openbare repository of back-uparchief dat je deelt. Een ZIP van de website- of resourcebestanden is geen back-up van de MDT-gegevens.

## Toegang en beschikbaarheid
De website-link is publiek bereikbaar, maar MDT-acties blijven afhankelijk van Discord-login, een online personage, dienststatus en de rechten in `p_mdt`. De gratis Render-service kan slapen; `/healthz` controleert alleen of de website draait, niet of FiveM of de database beschikbaar is. Voor continu gebruik kies je hosting die niet pauzeert en controleer je ook de verbinding met FiveM.

De actuele gratis limieten en slaapregels kunnen veranderen; bekijk Render's [free web services](https://render.com/docs/free) en [Node/Express deployment guide](https://render.com/docs/deploy-node-express-app).

## Kant van de FiveM-server
1. Vervang de map `p_mdt` door versie 2.3 en laat `IngameTablet = true` staan. Start de resource opnieuw. De resource voegt de benodigde indexen automatisch toe.
2. Pas `Config.Web` in `config.lua` aan: `Secret` (verplicht, anders staat de website uit), `Url` en eventueel `AllowedIp` (het IP van je VPS).
3. `FIVEM_URL` in de `.env` is het adres van je FiveM-server: `http://IP:30120/p_mdt/web/api`. Staat de website op dezelfde machine, gebruik dan `127.0.0.1`. Staat hij op een andere machine, zet dan `AllowedIp` in de config en laat poort 30120 enkel voor dat IP toe in je firewall.
4. Agenten moeten hun Discord aan hun FiveM laten gekoppeld hebben (Discord moet open staan als ze het spel starten), anders heeft de server hun Discord-ID niet.

## Beperkingen
- Gevangenis: het jail-script van je politiescript vraagt dat de agent binnen 30 m van de burger staat. Via de website is dat niet zo. Met `Config.Web.JailWithoutDistance = true` probeert p_mdt het daarom opnieuw zonder agent. Of dat werkt hangt af van je jail-script (zie `jailStatus` in de melding na een straf).
- De burger moet voor een celstraf online zijn, of anders wordt de celtijd bewaard tot hij inlogt.
- Foto's nemen in het spel zit er niet in; een foto zet je met een https-link.
- De webpagina houdt statische bestanden kort gecachet en controleert daarna met ETags of een bestand is gewijzigd. Vernieuw na een update de browser als je nog een oude pagina ziet.
- Meldingen komen in het spel nog steeds als berichtje binnen; op de website zie je ze binnen een paar seconden.
